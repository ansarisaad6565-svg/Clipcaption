# Clip Caption v3.4
- Auto captions (Hindi / English / Hinglish) with AI correction, emoji, styles, fonts
- Viral Shorts (Vizard-style): line-based clip cutting, editor pass, score breakdown
- Edit effects on export: punch zoom, caption pop, progress bar, color, fade
Online AI ke liye free Groq API key chahiye (console.groq.com/keys).
