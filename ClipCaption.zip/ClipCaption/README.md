# Clip Caption v2.1
Auto captions (Hindi / English / Hinglish) + smart emoji + styles + fonts.

Engines:
- Online AI (Whisper large-v3 via free Groq key): bahut accurate, AI spelling fix + smart emoji.
- Offline (Vosk): free, no key, kam accurate.
