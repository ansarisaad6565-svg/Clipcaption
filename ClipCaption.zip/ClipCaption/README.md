# Clip Caption v3.1
- Single video: auto captions (Hindi / English / Hinglish) + emoji + styles + fonts
- Lamba video se Viral Shorts (Vizard-style): viral score (Hook/Flow/Value/Trend), title, hook,
  description + hashtags, perfect start/end, Fit layout (blur background, crop nahi), hook title,
  captions + emoji.
Online AI ke liye free Groq API key chahiye (console.groq.com/keys).
