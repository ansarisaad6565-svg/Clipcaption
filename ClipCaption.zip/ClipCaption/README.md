# Clip Caption (Android)

Video chuno -> start/end time do (jaise 0:13 se 2:00) -> captions add karo -> export.
Output gallery ke Movies/ClipCaption folder me save hota hai.

## APK kaise banaye (GitHub se)
1. GitHub pe naya repo banao.
2. Is zip ke andar ke saare files repo me upload karo (".github" folder bhi).
3. Repo > Actions tab > "Build APK" workflow chalne do (ya "Run workflow" dabao).
4. Ban jane par run kholo > neeche Artifacts > "ClipCaption-APK" download karo.
5. Zip ke andar app-debug.apk ko phone me install karo.
