# Clip Caption v3.0
- Single video: auto captions (Hindi / English / Hinglish) + emoji + styles + fonts
- NEW: Lamba video (30+ min) se Viral Shorts: AI best moments dhundhta hai, 9:16 crop karke
  captions + emoji ke saath shorts banata hai.
Online AI ke liye free Groq API key chahiye (console.groq.com/keys).
