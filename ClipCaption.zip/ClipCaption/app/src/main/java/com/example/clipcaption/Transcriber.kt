package com.example.clipcaption

import android.content.Context
import android.net.Uri
import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer

object Transcriber {

    fun run(ctx: Context, uri: Uri, modelPath: String, status: (String) -> Unit): List<RawWord> {
        val model = Model(modelPath)
        val rec = Recognizer(model, 16000f)
        rec.setWords(true)
        val out = ArrayList<RawWord>()

        fun collect(json: String) {
            val arr = JSONObject(json).optJSONArray("result") ?: return
            for (i in 0 until arr.length()) {
                val w = arr.getJSONObject(i)
                out.add(
                    RawWord(
                        w.getString("word"),
                        (w.getDouble("start") * 1000).toLong(),
                        (w.getDouble("end") * 1000).toLong()
                    )
                )
            }
        }

        try {
            AudioDecoder.decode(
                ctx, uri,
                { buf, len -> if (rec.acceptWaveForm(buf, len)) collect(rec.result) },
                { p -> status("Awaaz sun raha hoon... $p%") }
            )
            collect(rec.finalResult)
        } finally {
            rec.close()
            model.close()
        }
        return out
    }
}
