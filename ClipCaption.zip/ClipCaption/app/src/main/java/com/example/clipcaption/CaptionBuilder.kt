package com.example.clipcaption

object CaptionBuilder {

    private fun clean(s: String): String =
        s.trim().trim('.', ',', ';', ':', '।', '"', '\'', '“', '”', '‘', '’', '(', ')', '-', '–', '…', '|')

    private fun endsSentence(s: String): Boolean {
        val c = s.trim().trim('"', '\'', ')', '”').lastOrNull() ?: return false
        return c == '.' || c == '?' || c == '!' || c == '।'
    }

    /**
     * lang: "hi" (Devanagari), "en" (English) or "hinglish" (Roman Hindi).
     * density: 0 = few emojis, 1 = medium, 2 = every caption.
     */
    fun build(raw: List<RawWord>, lang: String, perCap: Int, density: Int): MutableList<Caption> {
        val words = ArrayList<RawWord>()
        val sentenceEnd = ArrayList<Boolean>()
        for (w in raw) {
            val c = clean(w.text)
            if (c.isEmpty()) continue
            words.add(RawWord(c, w.startMs, w.endMs))
            sentenceEnd.add(endsSentence(w.text))
        }

        val groups = ArrayList<MutableList<RawWord>>()
        var cur = ArrayList<RawWord>()
        for ((idx, w) in words.withIndex()) {
            if (cur.isNotEmpty() && (cur.size >= perCap || w.startMs - cur.last().endMs > 700 ||
                        (cur.size >= 2 && w.startMs - cur.last().endMs > 350))) {
                groups.add(cur)
                cur = ArrayList()
            }
            cur.add(w)
            if (sentenceEnd[idx]) {
                groups.add(cur)
                cur = ArrayList()
            }
        }
        if (cur.isNotEmpty()) groups.add(cur)

        val fuzzy = density >= 1 && lang != "en"
        val result = ArrayList<Caption>()
        var genericCount = 0
        for ((gi, g) in groups.withIndex()) {
            val shownWords = g.map { rw ->
                val shown = if (lang == "hinglish") Translit.toRoman(rw.text) else rw.text
                Word(shown, rw.startMs, rw.endMs)
            }
            var emoji = ""
            for ((i, rw) in g.withIndex()) {
                val e = EmojiMap.find(fuzzy && Translit.hasDevanagari(rw.text), rw.text, shownWords[i].text)
                if (e != null) { emoji = e; break }
            }
            if (emoji.isEmpty() && density >= 2) {
                emoji = EmojiMap.generic[genericCount % EmojiMap.generic.size]
                genericCount++
            }
            val start = g.first().startMs
            var end = g.last().endMs + 600
            if (gi + 1 < groups.size) {
                val nextStart = groups[gi + 1].first().startMs
                // short pause: keep this caption on screen until the next one appears
                if (nextStart - g.last().endMs < 1500) end = nextStart
                else if (end > nextStart) end = nextStart
            }
            if (end - start < 250) end = start + 250
            result.add(Caption(shownWords, emoji, start, end))
        }
        dedupeEmoji(result)
        return result
    }

    /** Don't show the same emoji again within the next 2 captions. */
    fun dedupeEmoji(caps: List<Caption>) {
        var p1 = ""
        var p2 = ""
        for (c in caps) {
            if (c.emoji.isNotEmpty() && (c.emoji == p1 || c.emoji == p2)) c.emoji = ""
            p2 = p1
            p1 = c.emoji
        }
    }
}
