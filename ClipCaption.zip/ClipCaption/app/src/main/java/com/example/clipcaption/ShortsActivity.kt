package com.example.clipcaption

import android.content.ClipData
import android.content.ClipboardManager
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Shader
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.View
import android.view.WindowManager
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import java.io.File
import java.io.FileOutputStream
import kotlin.concurrent.thread
import kotlin.math.min

class ShortsActivity : AppCompatActivity() {

    private val counts = listOf(3, 4, 5, 6, 8, 10)
    private val lengths = listOf(20 to 40, 30 to 60, 45 to 75, 60 to 90)

    private var videoUri: Uri? = null
    private var videoW = 1920
    private var videoH = 1080
    private var durationMs = 0L
    private var raw: List<RawWord> = emptyList()
    private var rawKey = ""
    private var energy: FloatArray? = null
    private val moments = mutableListOf<Moment>()
    private var busy = false
    private var okCount = 0
    private var failCount = 0

    private lateinit var svMain: ScrollView
    private lateinit var videoView: VideoView
    private lateinit var tvInfo: TextView
    private lateinit var tvStatus: TextView
    private lateinit var progress: ProgressBar
    private lateinit var ivPreview: ImageView
    private lateinit var llMoments: LinearLayout
    private lateinit var llResults: LinearLayout
    private lateinit var etKey: EditText
    private lateinit var cbSmart: CheckBox
    private lateinit var cbEmoji: CheckBox
    private lateinit var cbHook: CheckBox
    private lateinit var spEdit: Spinner
    private lateinit var etHint: EditText
    private lateinit var spLang: Spinner
    private lateinit var spCount: Spinner
    private lateinit var spLength: Spinner
    private lateinit var spFormat: Spinner
    private lateinit var spStyle: Spinner
    private lateinit var spFont: Spinner
    private lateinit var spSize: Spinner
    private lateinit var spPos: Spinner
    private lateinit var spWords: Spinner
    private lateinit var spDensity: Spinner
    private lateinit var btnPick: Button
    private lateinit var btnFind: Button
    private lateinit var btnCreate: Button
    private lateinit var btnExportAll: Button
    private lateinit var btnSelAll: Button
    private lateinit var btnSelNone: Button

    private class Job(val m: Moment, val caps: List<Caption>, val frames: List<Bitmap>)

    private val handler = Handler(Looper.getMainLooper())
    private var stopPreview: Runnable? = null
    private var transformer: Transformer? = null

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) loadVideo(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_shorts)
        title = "Viral Shorts"

        svMain = findViewById(R.id.svMain)
        videoView = findViewById(R.id.videoView)
        tvInfo = findViewById(R.id.tvInfo)
        tvStatus = findViewById(R.id.tvStatus)
        progress = findViewById(R.id.progress)
        ivPreview = findViewById(R.id.ivPreview)
        llMoments = findViewById(R.id.llMoments)
        llResults = findViewById(R.id.llResults)
        etKey = findViewById(R.id.etKey)
        cbSmart = findViewById(R.id.cbSmart)
        cbEmoji = findViewById(R.id.cbEmoji)
        cbHook = findViewById(R.id.cbHook)
        spEdit = findViewById(R.id.spEdit)
        etHint = findViewById(R.id.etHint)
        spLang = findViewById(R.id.spLang)
        spCount = findViewById(R.id.spCount)
        spLength = findViewById(R.id.spLength)
        spFormat = findViewById(R.id.spFormat)
        spStyle = findViewById(R.id.spStyle)
        spFont = findViewById(R.id.spFont)
        spSize = findViewById(R.id.spSize)
        spPos = findViewById(R.id.spPos)
        spWords = findViewById(R.id.spWords)
        spDensity = findViewById(R.id.spDensity)
        btnPick = findViewById(R.id.btnPick)
        btnFind = findViewById(R.id.btnFind)
        btnCreate = findViewById(R.id.btnCreate)
        btnExportAll = findViewById(R.id.btnExportAll)
        btnSelAll = findViewById(R.id.btnSelAll)
        btnSelNone = findViewById(R.id.btnSelNone)

        setup(spLang, listOf("Hinglish (Roman Hindi)", "Hindi (देवनागरी)", "English"), 0)
        setup(spEdit, EditFx.levelNames, 0)
        setup(spCount, counts.map { "$it shorts" }, 3)
        setup(spLength, lengths.map { "${it.first}-${it.second} sec" }, 1)
        setup(spFormat, listOf("Fit - poori video + blur background (crop nahi)", "Fill - screen bhar (crop hoga)", "Original size"), 0)
        setup(spStyle, Presets.styles.map { it.name }, 2)
        setup(spFont, Presets.fonts.map { it.name }, 1)
        setup(spSize, Presets.sizeNames, 1)
        setup(spPos, Presets.positionNames, 0)
        setup(spWords, listOf("1 word", "2 words", "3 words", "4 words", "5 words"), 1)
        setup(spDensity, listOf("Kam (sirf pakke match)", "Medium", "Zyada (har caption par)"), 1)

        etKey.setText(getSharedPreferences("cc", MODE_PRIVATE).getString("groq", "") ?: "")

        val previewListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = updatePreview()
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        spStyle.onItemSelectedListener = previewListener
        spFont.onItemSelectedListener = previewListener
        spSize.onItemSelectedListener = previewListener
        spFormat.onItemSelectedListener = previewListener

        findViewById<Button>(R.id.btnKeyHelp).setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://console.groq.com/keys")))
        }
        btnPick.setOnClickListener { picker.launch("video/*") }
        btnFind.setOnClickListener { findMoments() }
        btnCreate.setOnClickListener { createShorts(moments.filter { it.selected }) }
        btnExportAll.setOnClickListener { createShorts(moments.toList()) }
        btnSelAll.setOnClickListener { moments.forEach { it.selected = true }; refreshMoments() }
        btnSelNone.setOnClickListener { moments.forEach { it.selected = false }; refreshMoments() }
        updatePreview()
    }

    private fun setup(sp: Spinner, items: List<String>, sel: Int) {
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        sp.setSelection(sel)
    }

    private fun ui(block: () -> Unit) = runOnUiThread(block)
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun setBusy(b: Boolean) {
        busy = b
        btnPick.isEnabled = !b
        btnFind.isEnabled = !b
        btnCreate.isEnabled = !b
        btnExportAll.isEnabled = !b
        if (b) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
    }

    // ---------------------------------------------------------------- video

    private fun loadVideo(uri: Uri) {
        try {
            val r = MediaMetadataRetriever()
            r.setDataSource(this, uri)
            durationMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1920
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1080
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            r.release()
            if (rot == 90 || rot == 270) { videoW = h; videoH = w } else { videoW = w; videoH = h }
        } catch (e: Exception) {
            toast("Video read nahi ho paya: ${e.message}")
            return
        }
        videoUri = uri
        raw = emptyList()
        rawKey = ""
        energy = null
        moments.clear()
        llMoments.removeAllViews()
        llResults.removeAllViews()
        videoView.setVideoURI(uri)
        videoView.setOnPreparedListener { it.isLooping = false; videoView.seekTo(1) }
        tvInfo.text = "Video: ${fmt(durationMs)}  (${videoW}x${videoH})"
        tvStatus.text = "Ab 'Viral moments dhundo' dabao."
        updatePreview()
    }

    // ---------------------------------------------------------------- find moments

    private fun findMoments() {
        val uri = videoUri
        if (uri == null) { toast("Pehle video upload karo"); return }
        if (busy) return
        val key = etKey.text.toString().trim()
        if (key.isEmpty()) {
            toast("Groq API key daalo (free)")
            etKey.requestFocus()
            return
        }
        getSharedPreferences("cc", MODE_PRIVATE).edit().putString("groq", key).apply()

        setBusy(true)
        progress.isIndeterminate = true

        val langPos = spLang.selectedItemPosition
        val count = counts[spCount.selectedItemPosition]
        val (minS, maxS) = lengths[spLength.selectedItemPosition]
        val langName = when (langPos) {
            0 -> "Hinglish (Hindi written in Roman letters)"
            1 -> "Hindi"
            else -> "English"
        }
        val hint = etHint.text.toString().trim()
        val hintPrefix = if (hint.isEmpty()) "" else "Names and keywords: $hint. "
        val cacheKey = "$uri|$langPos|$hint"

        thread {
            try {
                if (raw.isEmpty() || rawKey != cacheKey) {
                    ui { tvStatus.text = "Audio nikal raha hoon..." }
                    val pcm = File(cacheDir, "audio_long.pcm")
                    FileOutputStream(pcm).use { fo ->
                        AudioDecoder.decode(
                            this, uri,
                            { b, n -> fo.write(b, 0, n) },
                            { p -> ui { tvStatus.text = "Audio nikal raha hoon... $p%" } }
                        )
                    }
                    val apiLang = if (langPos == 2) "en" else "hi"
                    val prompt = hintPrefix + when (langPos) {
                        0 -> GroqClient.HINGLISH_PROMPT
                        1 -> GroqClient.HINDI_PROMPT
                        else -> ""
                    }
                    energy = try { AudioEnergy.perSecond(pcm) } catch (e: Exception) { null }
                    raw = GroqClient.transcribe(pcm, key, apiLang, prompt) { m -> ui { tvStatus.text = m } }
                    pcm.delete()
                    rawKey = cacheKey
                }

                if (raw.isEmpty()) {
                    ui { tvStatus.text = "Koi speech nahi mili. Dusri language try karo." }
                } else {
                    GroqClient.resetModels()
                    val found = ShortsFinder.find(key, raw, energy, durationMs, count, minS, maxS, langName) { m ->
                        ui { tvStatus.text = m }
                    }
                    val weak = GroqClient.modelsUsed.any { !it.contains("70b") }
                    val note = if (weak) " (Dhyan: free limit ki wajah se halka AI model bhi use hua, quality thodi kam ho sakti hai.)" else ""
                    ui {
                        moments.clear()
                        moments.addAll(found)
                        refreshMoments()
                        tvStatus.text = if (found.isEmpty()) "Koi achha moment nahi mila."
                        else "${found.size} viral moments mile. Preview dekho, chuno aur export karo.$note"
                    }
                }
            } catch (t: Throwable) {
                ui { tvStatus.text = "Error: ${t.message ?: t.javaClass.simpleName}" }
            } finally {
                ui { progress.isIndeterminate = false; setBusy(false) }
            }
        }
    }

    private fun refreshMoments() {
        llMoments.removeAllViews()
        moments.forEachIndexed { i, m ->
            val row = LinearLayout(this)
            row.orientation = LinearLayout.VERTICAL
            row.setPadding(0, 20, 0, 20)

            val cb = CheckBox(this)
            val title = if (m.title.isEmpty()) "Short" else m.title
            cb.text = "#${i + 1}   Viral score ${m.score}/100\n$title\n${fmt(m.startMs)} - ${fmt(m.endMs)}  (${(m.endMs - m.startMs) / 1000}s)"
            cb.isChecked = m.selected
            cb.setOnCheckedChangeListener { _, c -> m.selected = c; updateCreateLabel() }
            row.addView(cb)

            if (m.hook.isNotEmpty()) {
                val tv = TextView(this)
                tv.text = "Hook: " + m.hook
                tv.textSize = 14f
                row.addView(tv)
            }
            if (m.hookScore > 0) {
                val tv = TextView(this)
                tv.text = "Hook ${m.hookScore}/10  |  Flow ${m.flowScore}/10  |  Value ${m.valueScore}/10  |  Trend ${m.trendScore}/10"
                tv.textSize = 13f
                row.addView(tv)
            }
            if (m.reason.isNotEmpty()) {
                val tv = TextView(this)
                tv.text = m.reason
                tv.textSize = 13f
                row.addView(tv)
            }
            val post = (m.description + "\n" + m.hashtags).trim()
            if (post.isNotEmpty()) {
                val tv = TextView(this)
                tv.text = post
                tv.textSize = 13f
                row.addView(tv)
            }

            val btns = LinearLayout(this)
            btns.orientation = LinearLayout.HORIZONTAL
            val btn = Button(this)
            btn.text = "Preview"
            btn.setOnClickListener { preview(m) }
            btns.addView(btn)
            val one = Button(this)
            one.text = "Sirf ye export karo"
            one.setOnClickListener { createShorts(listOf(m)) }
            btns.addView(one)
            if (post.isNotEmpty()) {
                val cp = Button(this)
                cp.text = "Post text copy"
                cp.setOnClickListener {
                    val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("post", (m.title + "\n" + post).trim()))
                    toast("Copy ho gaya")
                }
                btns.addView(cp)
            }
            row.addView(btns)

            llMoments.addView(row)
        }
        updateCreateLabel()
    }

    private fun updateCreateLabel() {
        val n = moments.count { it.selected }
        btnCreate.text = "4. Tick kiye hue $n clips export karo"
        btnExportAll.text = "Sab ${moments.size} clips export karo"
    }

    private fun preview(m: Moment) {
        stopPreview?.let { handler.removeCallbacks(it) }
        svMain.smoothScrollTo(0, 0)
        videoView.seekTo(m.startMs.toInt())
        videoView.start()
        val r = Runnable { videoView.pause() }
        stopPreview = r
        handler.postDelayed(r, m.endMs - m.startMs)
    }

    // ---------------------------------------------------------------- style preview

    private fun outW(): Int = if (spFormat.selectedItemPosition == 2) videoW else 1080
    private fun outH(): Int = if (spFormat.selectedItemPosition == 2) videoH else 1920

    private fun makeRenderer(): CaptionRenderer = CaptionRenderer(
        outW(), outH(),
        Presets.styles[spStyle.selectedItemPosition],
        Presets.fonts[spFont.selectedItemPosition].typeface(),
        Presets.sizeScales[spSize.selectedItemPosition]
    )

    private fun updatePreview() {
        if (!::spFormat.isInitialized || !::ivPreview.isInitialized || !::spDensity.isInitialized) return
        try {
            val cap = makeRenderer().render(listOf("Ye", "caption", "aise", "dikhega"), 1, "🔥")
            val w = outW().coerceAtMost(1080).coerceAtLeast(600)
            val h = (cap.height * 2.2f).toInt().coerceAtLeast(160)
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            val p = Paint()
            p.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), 0xFF455A64.toInt(), 0xFF1B1B1B.toInt(), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
            c.drawBitmap(cap, (w - cap.width) / 2f, (h - cap.height) / 2f, null)
            ivPreview.setImageBitmap(out)
        } catch (e: Exception) {
            // preview is optional
        }
    }

    // ---------------------------------------------------------------- create shorts

    private fun createShorts(selected: List<Moment>) {
        val uri = videoUri
        if (uri == null) { toast("Pehle video upload karo"); return }
        if (selected.isEmpty()) { toast("Pehle moments dhundo aur kam se kam ek clip chuno"); return }
        if (busy) return

        val key = etKey.text.toString().trim()
        val langKey = when (spLang.selectedItemPosition) { 0 -> "hinglish"; 1 -> "hi"; else -> "en" }
        val perCap = spWords.selectedItemPosition + 1
        val density = spDensity.selectedItemPosition
        val smart = cbSmart.isChecked && key.isNotEmpty()
        val layoutMode = spFormat.selectedItemPosition

        setBusy(true)
        progress.isIndeterminate = true
        llResults.removeAllViews()
        okCount = 0
        failCount = 0
        val snapshot = raw

        thread {
            val jobs = ArrayList<Job>()
            try {
                for ((i, m) in selected.withIndex()) {
                    ui { tvStatus.text = "Captions aur emoji bana raha hoon... ${i + 1}/${selected.size}" }
                    val words = snapshot
                        .filter { it.startMs >= m.startMs - 50 && it.startMs < m.endMs }
                        .map {
                            RawWord(
                                it.text,
                                (it.startMs - m.startMs).coerceAtLeast(0),
                                (min(it.endMs, m.endMs) - m.startMs).coerceAtLeast(1)
                            )
                        }
                    var useWords = words
                    if (smart) {
                        try {
                            useWords = GroqClient.fixWords(key, words, langKey) { s -> ui { tvStatus.text = "Short ${i + 1}: $s" } }
                        } catch (e: GroqClient.ApiException) {
                            if (e.code == 401) throw e
                        } catch (e: Exception) {
                            // keep original words
                        }
                    }
                    val caps = CaptionBuilder.build(useWords, langKey, perCap, density)
                    if (smart) {
                        try {
                            GroqClient.smartFix(key, caps, langKey, density) { s -> ui { tvStatus.text = "Short ${i + 1}: $s" } }
                            CaptionBuilder.dedupeEmoji(caps)
                        } catch (e: Exception) {
                            // keep local captions/emojis if AI fix fails
                        }
                    }
                    var frames: List<Bitmap> = emptyList()
                    if (layoutMode == 0 && BlurFrames.needsBars(videoW, videoH, 1080, 1920)) {
                        ui { tvStatus.text = "Blur background bana raha hoon... ${i + 1}/${selected.size}" }
                        frames = BlurFrames.extract(this, uri, m.startMs, m.endMs, videoW, videoH, 1080, 1920)
                    }
                    jobs.add(Job(m, caps, frames))
                }
            } catch (t: Throwable) {
                ui {
                    tvStatus.text = "Error: ${t.message ?: t.javaClass.simpleName}"
                    progress.isIndeterminate = false
                    setBusy(false)
                }
                return@thread
            }
            ui {
                progress.isIndeterminate = false
                exportNext(uri, jobs, 0)
            }
        }
    }

    private fun exportNext(uri: Uri, jobs: List<Job>, idx: Int) {
        if (idx >= jobs.size) {
            setBusy(false)
            progress.progress = 0
            tvStatus.text = "Ho gaya! $okCount shorts Movies/ClipCaption me save hue." +
                    (if (failCount > 0) " ($failCount fail hue)" else "")
            return
        }
        val job = jobs[idx]
        val m = job.m
        val style = Presets.styles[spStyle.selectedItemPosition]
        val layoutMode = spFormat.selectedItemPosition
        val overlays = ArrayList<TextureOverlay>()
        if (layoutMode == 0 && job.frames.isNotEmpty()) {
            overlays.add(
                BlurBackgroundOverlay(job.frames, 1080, 1920, BlurFrames.videoRect(videoW, videoH, 1080, 1920))
            )
        }
        if (cbHook.isChecked && m.title.isNotBlank() && m.title.indexOf("Short moment") != 0) {
            val hookStyle = StyleSpec("Hook", Color.BLACK, 0, 0f, 0xFFFFD400.toInt(), false, 0, false, 0, false)
            val hookBmp = CaptionRenderer(outW(), outH(), hookStyle, Presets.fonts[1].typeface(), 0.85f)
                .render(m.title.split(" ").filter { it.isNotEmpty() }, -1, "")
            overlays.add(HookOverlay(hookBmp, 3500, 0.62f))
        }
        val level = spEdit.selectedItemPosition
        val clipMs = m.endMs - m.startMs
        EditFx.progressOverlay(level, clipMs, outW(), outH())?.let { overlays.add(0 + overlays.size, it) }
        overlays.add(
            CaptionBitmapOverlay(
                job.caps, makeRenderer(), cbEmoji.isChecked, spPos.selectedItemPosition,
                style.useHighlight, level < 2
            )
        )
        EditFx.fadeOverlay(level, clipMs, outW(), outH())?.let { overlays.add(it) }
        val clip = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(m.startMs)
            .setEndPositionMs(m.endMs)
            .build()
        val item = MediaItem.Builder().setUri(uri).setClippingConfiguration(clip).build()
        val effects = ArrayList<Effect>()
        effects.addAll(EditFx.videoEffects(level, EditFx.cutsFrom(job.caps)))
        when (layoutMode) {
            0 -> effects.add(Presentation.createForWidthAndHeight(1080, 1920, Presentation.LAYOUT_SCALE_TO_FIT))
            1 -> effects.add(Presentation.createForWidthAndHeight(1080, 1920, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP))
        }
        effects.add(OverlayEffect(ImmutableList.copyOf(overlays)))
        val edited = EditedMediaItem.Builder(item)
            .setEffects(Effects(emptyList(), effects))
            .build()

        val outFile = File(cacheDir, "short_${idx}_${System.currentTimeMillis()}.mp4")
        tvStatus.text = "Short ${idx + 1}/${jobs.size} export ho raha hai... (screen on rakho)"
        progress.progress = 0

        val t = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    handler.removeCallbacks(poller)
                    progress.progress = 100
                    saveShort(outFile, uri, jobs, idx)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    handler.removeCallbacks(poller)
                    failCount++
                    tvStatus.text = "Short ${idx + 1} fail: ${exportException.message}"
                    exportNext(uri, jobs, idx + 1)
                }
            })
            .build()
        transformer = t
        t.start(edited, outFile.absolutePath)
        handler.post(poller)
    }

    private val poller = object : Runnable {
        override fun run() {
            val t = transformer ?: return
            val holder = ProgressHolder()
            if (t.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) {
                progress.progress = holder.progress
            }
            handler.postDelayed(this, 300)
        }
    }

    private fun saveShort(file: File, uri: Uri, jobs: List<Job>, idx: Int) {
        thread {
            var saved: Uri? = null
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "ClipShort_${System.currentTimeMillis()}_${idx + 1}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ClipCaption")
                }
                saved = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (saved != null) {
                    contentResolver.openOutputStream(saved)?.use { out ->
                        file.inputStream().use { it.copyTo(out) }
                    }
                }
                file.delete()
            } catch (e: Exception) {
                saved = null
            }
            val result: Uri? = saved
            ui {
                if (result != null) {
                    okCount++
                    addResultRow(idx + 1, jobs[idx].m, result)
                } else {
                    failCount++
                }
                exportNext(uri, jobs, idx + 1)
            }
        }
    }

    private fun addResultRow(n: Int, m: Moment, saved: Uri) {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.VERTICAL
        row.setPadding(0, 12, 0, 12)

        val tv = TextView(this)
        tv.text = "Short #$n  (${(m.endMs - m.startMs) / 1000}s)  ${m.title}"
        row.addView(tv)

        val btns = LinearLayout(this)
        btns.orientation = LinearLayout.HORIZONTAL

        val play = Button(this)
        play.text = "Play"
        play.setOnClickListener {
            try {
                val i = Intent(Intent.ACTION_VIEW)
                i.setDataAndType(saved, "video/mp4")
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(i)
            } catch (e: Exception) {
                toast("Gallery me Movies/ClipCaption folder dekho")
            }
        }
        val share = Button(this)
        share.text = "Share"
        share.setOnClickListener {
            val i = Intent(Intent.ACTION_SEND)
            i.type = "video/mp4"
            i.putExtra(Intent.EXTRA_STREAM, saved)
            i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            startActivity(Intent.createChooser(i, "Share short"))
        }
        btns.addView(play)
        btns.addView(share)
        row.addView(btns)
        llResults.addView(row)
    }

    override fun onDestroy() {
        handler.removeCallbacks(poller)
        stopPreview?.let { handler.removeCallbacks(it) }
        transformer?.cancel()
        super.onDestroy()
    }
}
