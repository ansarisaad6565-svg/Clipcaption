package com.example.clipcaption

import java.io.File
import java.io.RandomAccessFile
import kotlin.math.abs

/** Makes quiet recordings louder before speech recognition (better accuracy). */
object AudioNormalize {

    fun normalize(pcm: File) {
        val hist = IntArray(257)
        var total = 0L
        RandomAccessFile(pcm, "r").use { raf ->
            val buf = ByteArray(65536)
            while (true) {
                val n = raf.read(buf)
                if (n <= 1) break
                var i = 0
                while (i + 1 < n) {
                    val s = (buf[i + 1].toInt() shl 8) or (buf[i].toInt() and 0xFF)
                    hist[(abs(s) shr 7).coerceAtMost(256)]++
                    total++
                    i += 2
                }
            }
        }
        if (total < 16000) return
        var acc = 0L
        var bin = 0
        val target = (total * 0.9995).toLong()
        for (b in 0..256) {
            acc += hist[b]
            if (acc >= target) { bin = b; break }
        }
        val level = ((bin + 1) shl 7).coerceAtLeast(200)
        val gain = (0.85 * 32767.0 / level).coerceAtMost(6.0)
        if (gain < 1.2) return

        RandomAccessFile(pcm, "rw").use { raf ->
            val buf = ByteArray(65536)
            var pos = 0L
            while (true) {
                raf.seek(pos)
                var n = raf.read(buf)
                if (n <= 1) break
                n -= n % 2
                var i = 0
                while (i + 1 < n) {
                    val s = (buf[i + 1].toInt() shl 8) or (buf[i].toInt() and 0xFF)
                    val v = (s * gain).toInt().coerceIn(-32768, 32767)
                    buf[i] = (v and 0xFF).toByte()
                    buf[i + 1] = ((v shr 8) and 0xFF).toByte()
                    i += 2
                }
                raf.seek(pos)
                raf.write(buf, 0, n)
                pos += n
            }
        }
    }
}
