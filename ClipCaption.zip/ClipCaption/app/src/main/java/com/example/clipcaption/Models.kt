package com.example.clipcaption

import android.graphics.Color
import android.graphics.Typeface
import org.json.JSONArray
import org.json.JSONObject

data class RawWord(val text: String, val startMs: Long, val endMs: Long)

data class Word(val text: String, val startMs: Long, val endMs: Long)

class Caption(var words: List<Word>, var emoji: String, var startMs: Long, var endMs: Long) {
    val text: String get() = words.joinToString(" ") { it.text }

    /** Replace the text; word timings are spread evenly over the caption duration. */
    fun setText(t: String) {
        val parts = t.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (parts.isEmpty()) return
        val dur = (endMs - startMs).coerceAtLeast(parts.size * 100L)
        val step = dur / parts.size
        words = parts.mapIndexed { i, p -> Word(p, startMs + i * step, startMs + (i + 1) * step) }
    }
}

data class StyleSpec(
    val name: String,
    val textColor: Int,
    val strokeColor: Int,
    val strokeRatio: Float,
    val boxColor: Int,
    val useHighlight: Boolean,
    val highlightColor: Int,
    val shadow: Boolean,
    val glowColor: Int,
    val allCaps: Boolean
)

data class FontSpec(val name: String, val family: String, val style: Int) {
    fun typeface(): Typeface = Typeface.create(family, style)
}

object Presets {
    val styles = listOf(
        StyleSpec("Classic Box", Color.WHITE, 0, 0f, 0xB3000000.toInt(), false, 0, false, 0, false),
        StyleSpec("Yellow Pop", 0xFFFFD400.toInt(), Color.BLACK, 0.14f, 0, false, 0, true, 0, true),
        StyleSpec("Karaoke Highlight", Color.WHITE, Color.BLACK, 0.14f, 0, true, 0xFFFFE600.toInt(), true, 0, true),
        StyleSpec("Green Highlight", Color.WHITE, Color.BLACK, 0.14f, 0, true, 0xFF00E676.toInt(), true, 0, true),
        StyleSpec("Neon Glow", 0xFFE0FFFF.toInt(), 0, 0f, 0, false, 0, false, 0xFF00E5FF.toInt(), false),
        StyleSpec("Red Box Bold", Color.WHITE, 0, 0f, 0xFFE53935.toInt(), false, 0, false, 0, true),
        StyleSpec("Comic Red Outline", Color.WHITE, 0xFFD50000.toInt(), 0.18f, 0, false, 0, true, 0, true),
        StyleSpec("Minimal Shadow", Color.WHITE, 0, 0f, 0, false, 0, true, 0, false)
    )

    val fonts = listOf(
        FontSpec("Modern", "sans-serif-medium", Typeface.NORMAL),
        FontSpec("Heavy Bold", "sans-serif-black", Typeface.NORMAL),
        FontSpec("Condensed", "sans-serif-condensed", Typeface.BOLD),
        FontSpec("Classic Serif", "serif", Typeface.BOLD),
        FontSpec("Handwriting", "cursive", Typeface.BOLD),
        FontSpec("Casual", "casual", Typeface.NORMAL),
        FontSpec("Typewriter", "monospace", Typeface.BOLD),
        FontSpec("Light", "sans-serif-light", Typeface.NORMAL)
    )

    val sizeNames = listOf("Chhota", "Medium", "Bada", "Bahut bada")
    val sizeScales = listOf(0.8f, 1.0f, 1.25f, 1.5f)
    val positionNames = listOf("Neeche (Bottom)", "Beech me (Middle)", "Upar (Top)")

    val syncNames = listOf(
        "Caption sync: Normal",
        "Thoda pehle (-0.2s)",
        "Thoda baad me (+0.2s)",
        "Bahut pehle (-0.4s)",
        "Bahut baad me (+0.4s)"
    )
    val syncMs = listOf(0L, -200L, 200L, -400L, 400L)

    val langNames = listOf(
        "Auto: English -> English, Hindi -> Hinglish (Roman)",
        "Hindi (देवनागरी)",
        "English"
    )
}

/** One spoken line of the transcript. loud = high vocal energy (laughter, excitement). */
data class Line(val startMs: Long, val endMs: Long, val text: String, val loud: Boolean = false)

/** A candidate viral short moment (Vizard-style: score, hook, title, description, hashtags). */
class Moment(
    var startMs: Long,
    var endMs: Long,
    var title: String,
    var score: Int,
    var reason: String,
    var selected: Boolean = true,
    var hook: String = "",
    var description: String = "",
    var hashtags: String = "",
    var hookScore: Int = 0,
    var flowScore: Int = 0,
    var valueScore: Int = 0,
    var trendScore: Int = 0,
    var words: List<RawWord>? = null
) {
    fun copyWith(s: Long, e: Long) = Moment(
        s, e, title, score, reason, selected, hook, description, hashtags,
        hookScore, flowScore, valueScore, trendScore, words
    )

    fun toJson(): JSONObject {
        val o = JSONObject()
            .put("s", startMs).put("e", endMs).put("title", title).put("score", score)
            .put("reason", reason).put("sel", selected).put("hook", hook).put("desc", description)
            .put("tags", hashtags).put("hs", hookScore).put("fs", flowScore)
            .put("vs", valueScore).put("ts", trendScore)
        val w = words
        if (w != null) {
            val a = JSONArray()
            for (x in w) a.put(JSONArray().put(x.text).put(x.startMs).put(x.endMs))
            o.put("words", a)
        }
        return o
    }

    companion object {
        fun fromJson(o: JSONObject): Moment {
            var words: List<RawWord>? = null
            val a = o.optJSONArray("words")
            if (a != null) {
                val list = ArrayList<RawWord>()
                for (i in 0 until a.length()) {
                    val x = a.optJSONArray(i) ?: continue
                    list.add(RawWord(x.optString(0, ""), x.optLong(1, 0), x.optLong(2, 0)))
                }
                words = list
            }
            return Moment(
                o.optLong("s"), o.optLong("e"), o.optString("title", ""), o.optInt("score", 0),
                o.optString("reason", ""), o.optBoolean("sel", true), o.optString("hook", ""),
                o.optString("desc", ""), o.optString("tags", ""), o.optInt("hs", 0), o.optInt("fs", 0),
                o.optInt("vs", 0), o.optInt("ts", 0), words
            )
        }
    }
}
