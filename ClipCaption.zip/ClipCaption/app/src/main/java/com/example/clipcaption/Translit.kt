package com.example.clipcaption

/** Devanagari -> natural Hinglish (Roman) transliteration. */
object Translit {

    private val common = mapOf(
        "है" to "hai", "हैं" to "hain", "हूँ" to "hoon", "हूं" to "hoon", "में" to "mein", "मैं" to "main",
        "और" to "aur", "क्या" to "kya", "नहीं" to "nahi", "यह" to "yeh", "वह" to "woh", "तो" to "toh",
        "भी" to "bhi", "से" to "se", "को" to "ko", "का" to "ka", "की" to "ki", "के" to "ke",
        "कि" to "ki", "ये" to "ye", "वो" to "woh", "हम" to "hum", "आप" to "aap", "तुम" to "tum",
        "तू" to "tu", "मेरा" to "mera", "मेरी" to "meri", "मेरे" to "mere", "तेरा" to "tera",
        "तेरी" to "teri", "तेरे" to "tere", "उसका" to "uska", "उसकी" to "uski", "उसे" to "use",
        "हमारा" to "hamara", "हमारी" to "hamari", "आपका" to "aapka", "आपकी" to "aapki", "आपके" to "aapke",
        "था" to "tha", "थी" to "thi", "थे" to "the", "हो" to "ho", "होगा" to "hoga", "होगी" to "hogi",
        "होता" to "hota", "होती" to "hoti", "होते" to "hote", "हुआ" to "hua", "हुई" to "hui", "हुए" to "hue",
        "कर" to "kar", "करो" to "karo", "करना" to "karna", "करते" to "karte", "करता" to "karta",
        "करती" to "karti", "किया" to "kiya", "करें" to "karein", "करूँगा" to "karunga", "जो" to "jo",
        "ही" to "hi", "पर" to "par", "एक" to "ek", "दो" to "do", "तीन" to "teen", "चार" to "chaar",
        "पाँच" to "paanch", "बहुत" to "bahut", "बोहोत" to "bohot", "अच्छा" to "accha", "अच्छी" to "acchi",
        "कैसे" to "kaise", "कैसा" to "kaisa", "कैसी" to "kaisi", "क्यों" to "kyun", "क्यूँ" to "kyun",
        "लेकिन" to "lekin", "मगर" to "magar", "अब" to "ab", "जब" to "jab", "तब" to "tab",
        "यहाँ" to "yahan", "यहां" to "yahan", "वहाँ" to "wahan", "वहां" to "wahan", "कहाँ" to "kahan",
        "कब" to "kab", "कौन" to "kaun", "कुछ" to "kuch", "सब" to "sab", "सभी" to "sabhi",
        "बस" to "bas", "फिर" to "phir", "अभी" to "abhi", "कभी" to "kabhi", "हमेशा" to "hamesha",
        "बात" to "baat", "लोग" to "log", "लोगों" to "logon", "दोस्तों" to "dosto", "दोस्त" to "dost",
        "भाई" to "bhai", "यार" to "yaar", "प्यार" to "pyaar", "दिल" to "dil", "ज़िंदगी" to "zindagi",
        "जिंदगी" to "zindagi", "वीडियो" to "video", "चैनल" to "channel", "सब्सक्राइब" to "subscribe",
        "लाइक" to "like", "शेयर" to "share", "कमेंट" to "comment", "ओके" to "okay", "ठीक" to "theek",
        "सही" to "sahi", "गलत" to "galat", "मतलब" to "matlab", "समझ" to "samajh", "देखो" to "dekho",
        "देखिए" to "dekhiye", "सुनो" to "suno", "बोलो" to "bolo", "चलो" to "chalo", "आओ" to "aao",
        "जाओ" to "jao", "रुको" to "ruko", "इसलिए" to "isliye", "इसलिये" to "isliye", "क्योंकि" to "kyunki",
        "जैसे" to "jaise", "वैसे" to "waise", "ऐसे" to "aise", "ऐसा" to "aisa", "ऐसी" to "aisi",
        "वैसा" to "waisa", "इस" to "is", "उस" to "us", "इन" to "in", "उन" to "un", "कोई" to "koi",
        "किसी" to "kisi", "सबसे" to "sabse", "ज्यादा" to "zyada", "ज़्यादा" to "zyada", "थोड़ा" to "thoda",
        "थोड़ी" to "thodi", "बहुत ही" to "bahut hi", "आज" to "aaj", "कल" to "kal", "परसों" to "parson",
        "रात" to "raat", "दिन" to "din", "समय" to "samay", "वक्त" to "waqt", "पैसा" to "paisa",
        "पैसे" to "paise", "काम" to "kaam", "घर" to "ghar", "नाम" to "naam", "साथ" to "saath",
        "लिए" to "liye", "लिये" to "liye", "बाद" to "baad", "पहले" to "pehle", "सिर्फ" to "sirf",
        "बिल्कुल" to "bilkul", "शुरू" to "shuru", "खत्म" to "khatam", "मुझे" to "mujhe", "तुझे" to "tujhe",
        "हमें" to "hamein", "तुम्हें" to "tumhein", "उसने" to "usne", "मैंने" to "maine", "तुमने" to "tumne",
        "आपने" to "aapne", "हमने" to "humne", "जी" to "ji", "हाँ" to "haan", "हां" to "haan",
        "ना" to "na", "न" to "na", "अरे" to "arre", "वाह" to "wah", "ओह" to "oh", "सुन" to "sun",
        "देख" to "dekh", "बोल" to "bol", "चल" to "chal", "आ" to "aa", "जा" to "ja", "रहा" to "raha",
        "रही" to "rahi", "रहे" to "rahe", "गया" to "gaya", "गई" to "gayi", "गए" to "gaye",
        "सकता" to "sakta", "सकती" to "sakti", "सकते" to "sakte", "चाहिए" to "chahiye", "चाहता" to "chahta",
        "पता" to "pata", "लगता" to "lagta", "लगा" to "laga", "मिला" to "mila", "मिलता" to "milta",
        "बना" to "bana", "बनाया" to "banaya", "दिया" to "diya", "लिया" to "liya", "कहा" to "kaha",
        "बोला" to "bola", "देखा" to "dekha", "सुना" to "suna", "पढ़ना" to "padhna", "पढ़" to "padh",
        "फोटो" to "photo", "फ़ोन" to "phone", "फोन" to "phone", "मोबाइल" to "mobile", "इंडिया" to "India",
        "भारत" to "Bharat", "सर" to "sir", "मैम" to "ma'am", "प्लीज" to "please", "सॉरी" to "sorry",
        "थैंक्यू" to "thank you", "हेलो" to "hello", "हाय" to "hi", "फ्रेंड्स" to "friends",
        "फ्रेंड" to "friend", "लव" to "love", "गुड" to "good", "बेस्ट" to "best", "सुपर" to "super"
    )

    private val cons = mapOf(
        'क' to "k", 'ख' to "kh", 'ग' to "g", 'घ' to "gh", 'ङ' to "ng",
        'च' to "ch", 'छ' to "chh", 'ज' to "j", 'झ' to "jh", 'ञ' to "n",
        'ट' to "t", 'ठ' to "th", 'ड' to "d", 'ढ' to "dh", 'ण' to "n",
        'त' to "t", 'थ' to "th", 'द' to "d", 'ध' to "dh", 'न' to "n",
        'प' to "p", 'फ' to "ph", 'ब' to "b", 'भ' to "bh", 'म' to "m",
        'य' to "y", 'र' to "r", 'ल' to "l", 'व' to "v",
        'श' to "sh", 'ष' to "sh", 'स' to "s", 'ह' to "h", 'ळ' to "l",
        '\u0958' to "q", '\u0959' to "kh", '\u095A' to "gh", '\u095B' to "z",
        '\u095C' to "r", '\u095D' to "rh", '\u095E' to "f", '\u095F' to "y"
    )

    private val nukta = mapOf(
        "k" to "q", "kh" to "kh", "g" to "g", "j" to "z", "d" to "r", "dh" to "rh", "ph" to "f"
    )

    private val indep = mapOf(
        'अ' to "a", 'आ' to "aa", 'इ' to "i", 'ई' to "ee", 'उ' to "u", 'ऊ' to "oo",
        'ऋ' to "ri", 'ए' to "e", 'ऐ' to "ai", 'ओ' to "o", 'औ' to "au", 'ऑ' to "o"
    )

    // "aa", "ee", "oo" are shortened at the end of a word (chalta, meri, tu)
    private val matra = mapOf(
        'ा' to "aa", 'ि' to "i", 'ी' to "ee", 'ु' to "u", 'ू' to "oo", 'े' to "e",
        'ै' to "ai", 'ो' to "o", 'ौ' to "au", 'ृ' to "ri", 'ॉ' to "o", 'ॅ' to "e"
    )

    private class Syl(var c: String, var v: String?) {
        var halant = false
        var nasal = ""
    }

    fun hasDevanagari(s: String): Boolean = s.any { it in '\u0900'..'\u097F' }

    fun toRoman(word: String): String {
        common[word]?.let { return it }
        if (!hasDevanagari(word)) return word

        val syls = ArrayList<Syl>()
        for (ch in word) {
            when {
                cons.containsKey(ch) -> syls.add(Syl(cons[ch]!!, null))
                ch == '\u094D' -> syls.lastOrNull()?.halant = true
                matra.containsKey(ch) -> {
                    val last = syls.lastOrNull()
                    if (last != null) { last.v = matra[ch]; last.halant = false }
                }
                indep.containsKey(ch) -> syls.add(Syl("", indep[ch]!!))
                ch == '\u0902' || ch == '\u0901' -> syls.lastOrNull()?.nasal = "n"
                ch == '\u0903' -> syls.lastOrNull()?.nasal = "h"
                ch == '\u093C' -> {
                    val last = syls.lastOrNull()
                    if (last != null) nukta[last.c]?.let { last.c = it }
                }
                ch == '\u0964' || ch == '\u0965' -> { /* danda: ignore */ }
                else -> syls.add(Syl(ch.toString(), ""))
            }
        }

        val n = syls.size
        val keep = BooleanArray(n)
        val sb = StringBuilder()
        for (i in 0 until n) {
            val s = syls[i]
            val v = s.v
            val isLast = i == n - 1
            if (v != null) {
                val vv = when (v) {
                    "aa" -> if (isLast) "a" else "aa"
                    "ee" -> if (isLast) "i" else "ee"
                    "oo" -> if (isLast) "u" else "oo"
                    else -> v
                }
                sb.append(s.c).append(vv).append(s.nasal)
                keep[i] = v.isNotEmpty()
            } else if (s.halant) {
                sb.append(s.c).append(s.nasal)
                keep[i] = false
            } else {
                val prevOk = i > 0 && keep[i - 1]
                val nextExplicit = i + 1 < n && !syls[i + 1].v.isNullOrEmpty()
                val delete = isLast || (prevOk && nextExplicit)
                sb.append(s.c)
                if (!delete) sb.append("a")
                sb.append(s.nasal)
                keep[i] = !delete
            }
        }
        return sb.toString()
    }
}
