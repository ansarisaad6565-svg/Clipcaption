package com.example.clipcaption

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.PorterDuff
import android.graphics.PorterDuffXfermode
import android.graphics.Rect
import android.media.MediaMetadataRetriever
import android.net.Uri
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlaySettings
import kotlin.math.max
import kotlin.math.min

/** Small blurred snapshots (one per second) of the clip, used as moving blurred background. */
object BlurFrames {

    private const val TINY_W = 54
    private const val TINY_H = 96

    fun extract(
        ctx: Context, uri: Uri, startMs: Long, endMs: Long,
        videoW: Int, videoH: Int, outW: Int, outH: Int
    ): List<Bitmap> {
        val frames = ArrayList<Bitmap>()
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            val srcW = 160
            val srcH = max(2, (160f * videoH / videoW).toInt())
            val option = if (videoW > 2000) MediaMetadataRetriever.OPTION_CLOSEST_SYNC
            else MediaMetadataRetriever.OPTION_CLOSEST
            val targetAspect = outW.toFloat() / outH
            var t = startMs
            while (t <= endMs + 1000) {
                val src = try {
                    r.getScaledFrameAtTime(t * 1000, option, srcW, srcH)
                } catch (e: Exception) {
                    null
                }
                if (src != null) {
                    frames.add(makeBlur(src, targetAspect))
                } else if (frames.isNotEmpty()) {
                    frames.add(frames.last())
                }
                t += 1000
            }
        } catch (e: Exception) {
            // no blurred background if frames cannot be read
        } finally {
            try { r.release() } catch (e: Exception) {}
        }
        return frames
    }

    private fun makeBlur(src: Bitmap, targetAspect: Float): Bitmap {
        val sw = src.width
        val sh = src.height
        var cw = sw
        var ch = sh
        if (sw.toFloat() / sh > targetAspect) cw = (sh * targetAspect).toInt() else ch = (sw / targetAspect).toInt()
        cw = max(2, min(cw, sw))
        ch = max(2, min(ch, sh))
        val cropped = Bitmap.createBitmap(src, (sw - cw) / 2, (sh - ch) / 2, cw, ch)
        val small = Bitmap.createScaledBitmap(cropped, TINY_W, TINY_H, true)
        val mutable = small.copy(Bitmap.Config.ARGB_8888, true)
        boxBlur(mutable, 3)
        boxBlur(mutable, 3)
        return mutable
    }

    private fun boxBlur(bmp: Bitmap, radius: Int) {
        val w = bmp.width
        val h = bmp.height
        val px = IntArray(w * h)
        bmp.getPixels(px, 0, w, 0, 0, w, h)
        val tmp = IntArray(w * h)
        // horizontal
        for (y in 0 until h) {
            for (x in 0 until w) {
                var r = 0; var g = 0; var b = 0; var n = 0
                for (k in -radius..radius) {
                    val xx = x + k
                    if (xx < 0 || xx >= w) continue
                    val c = px[y * w + xx]
                    r += (c shr 16) and 0xFF; g += (c shr 8) and 0xFF; b += c and 0xFF; n++
                }
                tmp[y * w + x] = (0xFF shl 24) or ((r / n) shl 16) or ((g / n) shl 8) or (b / n)
            }
        }
        // vertical
        for (y in 0 until h) {
            for (x in 0 until w) {
                var r = 0; var g = 0; var b = 0; var n = 0
                for (k in -radius..radius) {
                    val yy = y + k
                    if (yy < 0 || yy >= h) continue
                    val c = tmp[yy * w + x]
                    r += (c shr 16) and 0xFF; g += (c shr 8) and 0xFF; b += c and 0xFF; n++
                }
                px[y * w + x] = (0xFF shl 24) or ((r / n) shl 16) or ((g / n) shl 8) or (b / n)
            }
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h)
    }

    /** Where the real (un-blurred) video sits inside the output frame. */
    fun videoRect(videoW: Int, videoH: Int, outW: Int, outH: Int): Rect {
        val s = min(outW.toFloat() / videoW, outH.toFloat() / videoH)
        val w = videoW * s
        val h = videoH * s
        val l = ((outW - w) / 2f).toInt()
        val t = ((outH - h) / 2f).toInt()
        return Rect(l, t, (l + w).toInt(), (t + h).toInt())
    }

    fun needsBars(videoW: Int, videoH: Int, outW: Int, outH: Int): Boolean {
        val r = videoRect(videoW, videoH, outW, outH)
        return (outW - r.width()) > 4 || (outH - r.height()) > 4
    }
}

/** Full-frame blurred background with a transparent hole where the sharp video shows through. */
class BlurBackgroundOverlay(
    private val frames: List<Bitmap>,
    private val outW: Int,
    private val outH: Int,
    private val videoRect: Rect
) : BitmapOverlay() {

    private var lastQ = -1L
    private var last: Bitmap = Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888)
    private val blend = Paint()
    private val scalePaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val clearPaint = Paint().apply { xfermode = PorterDuffXfermode(PorterDuff.Mode.CLEAR) }
    private val hole = Rect(videoRect.left + 2, videoRect.top + 2, videoRect.right - 2, videoRect.bottom - 2)

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        if (frames.isEmpty()) return last
        val ms = presentationTimeUs / 1000
        val q = ms / 200
        if (q == lastQ) return last
        lastQ = q

        val pos = q * 200 / 1000.0
        val k = pos.toInt().coerceIn(0, frames.size - 1)
        val k2 = (k + 1).coerceAtMost(frames.size - 1)
        val frac = (pos - k).toFloat().coerceIn(0f, 1f)

        val a = frames[k]
        val tiny = Bitmap.createBitmap(a.width, a.height, Bitmap.Config.ARGB_8888)
        val tc = Canvas(tiny)
        tc.drawBitmap(a, 0f, 0f, null)
        if (k2 != k) {
            blend.alpha = (frac * 255).toInt()
            tc.drawBitmap(frames[k2], 0f, 0f, blend)
        }

        val bmp = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawBitmap(tiny, null, Rect(0, 0, outW, outH), scalePaint)
        c.drawColor(0x40000000)
        c.drawRect(hole, clearPaint)
        last = bmp
        return bmp
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings =
        OverlaySettings.Builder().setBackgroundFrameAnchor(0f, 0f).build()
}

/** Hook title shown at the top during the first seconds. */
class HookOverlay(
    private val bmp: Bitmap,
    private val showMs: Long,
    private val y: Float
) : BitmapOverlay() {

    private val blank: Bitmap = Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888)

    override fun getBitmap(presentationTimeUs: Long): Bitmap =
        if (presentationTimeUs / 1000 < showMs) bmp else blank

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings =
        OverlaySettings.Builder().setBackgroundFrameAnchor(0f, y).build()
}
