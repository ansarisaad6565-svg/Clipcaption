package com.example.clipcaption

import kotlin.math.max
import kotlin.math.min

object TextSim {
    private fun core(s: String): String =
        s.lowercase().filter { it.isLetterOrDigit() || it.code in 0x0900..0x097F }

    private fun lev(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val c = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = min(min(cur[j - 1] + 1, prev[j] + 1), prev[j - 1] + c)
            }
            val t = prev; prev = cur; cur = t
        }
        return prev[b.length]
    }

    /** 1.0 = identical, 0.0 = completely different (ignores case and punctuation). */
    fun ratio(a: String, b: String): Double {
        val x = core(a)
        val y = core(b)
        if (x.isEmpty() && y.isEmpty()) return 1.0
        return 1.0 - lev(x, y).toDouble() / max(x.length, y.length)
    }
}

/** Keeps word timings when the user edits the text of a clip. */
object WordAlign {

    private fun same(a: String, b: String): Boolean =
        a.lowercase().trim('.', ',', '?', '!', ';', ':', '।') == b.lowercase().trim('.', ',', '?', '!', ';', ':', '।')

    fun apply(old: List<RawWord>, newText: String): List<RawWord> {
        val nw = newText.trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
        if (old.isEmpty() || nw.isEmpty()) return old
        if (nw.size == old.size) return nw.mapIndexed { i, t -> RawWord(t, old[i].startMs, old[i].endMs) }

        val n = old.size
        val m = nw.size
        val dp = Array(n + 1) { IntArray(m + 1) }
        for (i in 0..n) dp[i][0] = i
        for (j in 0..m) dp[0][j] = j
        for (i in 1..n) for (j in 1..m) {
            val c = if (same(old[i - 1].text, nw[j - 1])) 0 else 1
            dp[i][j] = min(dp[i - 1][j - 1] + c, min(dp[i - 1][j] + 1, dp[i][j - 1] + 1))
        }
        val st = LongArray(m) { -1L }
        val en = LongArray(m) { -1L }
        var i = n
        var j = m
        while (i > 0 || j > 0) {
            if (i > 0 && j > 0 && dp[i][j] == dp[i - 1][j - 1] + (if (same(old[i - 1].text, nw[j - 1])) 0 else 1)) {
                st[j - 1] = old[i - 1].startMs
                en[j - 1] = old[i - 1].endMs
                i--; j--
            } else if (j > 0 && dp[i][j] == dp[i][j - 1] + 1) {
                j--
            } else {
                i--
            }
        }
        // inserted words: spread evenly between their known neighbours
        var k = 0
        while (k < m) {
            if (st[k] >= 0) { k++; continue }
            var r = k
            while (r < m && st[r] < 0) r++
            val prevEnd = if (k > 0) en[k - 1] else old.first().startMs
            val nextStart = if (r < m) st[r] else old.last().endMs
            val span = max(1L, nextStart - prevEnd)
            val cnt = r - k
            for (q in 0 until cnt) {
                st[k + q] = prevEnd + span * q / cnt
                en[k + q] = prevEnd + span * (q + 1) / cnt
            }
            k = r
        }
        return nw.mapIndexed { idx, t -> RawWord(t, st[idx], en[idx]) }
    }
}
