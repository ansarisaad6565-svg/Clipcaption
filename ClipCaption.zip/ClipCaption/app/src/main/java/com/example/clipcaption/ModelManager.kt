package com.example.clipcaption

import android.content.Context
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.util.zip.ZipInputStream

/** Downloads the offline speech model once (about 40 MB), then it works without internet. */
object ModelManager {

    private fun urlFor(code: String): String = when (code) {
        "hi" -> "https://alphacephei.com/vosk/models/vosk-model-small-hi-0.22.zip"
        else -> "https://alphacephei.com/vosk/models/vosk-model-en-us-0.22-lgraph.zip"
    }

    fun ensure(ctx: Context, code: String, status: (String) -> Unit): String {
        val dir = File(ctx.filesDir, "vosk_$code")
        val ready = File(dir, ".ready")
        if (ready.exists()) {
            findRoot(dir)?.let { return it.absolutePath }
        }
        dir.deleteRecursively()
        dir.mkdirs()

        val zip = File(ctx.cacheDir, "model_$code.zip")
        download(urlFor(code), zip, status)

        status("Model extract ho raha hai...")
        val base = dir.canonicalPath
        ZipInputStream(zip.inputStream().buffered()).use { zis ->
            while (true) {
                val e = zis.nextEntry ?: break
                val target = File(dir, e.name)
                if (!target.canonicalPath.startsWith(base)) continue
                if (e.isDirectory) {
                    target.mkdirs()
                } else {
                    target.parentFile?.mkdirs()
                    target.outputStream().use { zis.copyTo(it) }
                }
            }
        }
        zip.delete()
        val root = findRoot(dir) ?: throw IOException("Model files nahi mile")
        ready.writeText("ok")
        return root.absolutePath
    }

    private fun findRoot(d: File): File? {
        if (File(d, "am").isDirectory) return d
        d.listFiles()?.filter { it.isDirectory }?.forEach { sub ->
            findRoot(sub)?.let { return it }
        }
        return null
    }

    private fun download(url: String, dest: File, status: (String) -> Unit) {
        val conn = URL(url).openConnection() as HttpURLConnection
        conn.connectTimeout = 20000
        conn.readTimeout = 30000
        conn.instanceFollowRedirects = true
        try {
            conn.connect()
            if (conn.responseCode !in 200..299) throw IOException("Download fail (HTTP ${conn.responseCode}). Internet check karo.")
            val total = conn.contentLengthLong
            var done = 0L
            var lastPct = -1
            conn.inputStream.use { input ->
                dest.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        out.write(buf, 0, n)
                        done += n
                        if (total > 0) {
                            val pct = (done * 100 / total).toInt()
                            if (pct != lastPct && pct % 3 == 0) {
                                lastPct = pct
                                status("Speech model download ho raha hai (sirf pehli baar)... $pct%")
                            }
                        }
                    }
                }
            }
        } finally {
            conn.disconnect()
        }
    }
}
