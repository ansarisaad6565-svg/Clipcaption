package com.example.clipcaption

import java.io.File
import java.io.RandomAccessFile
import kotlin.math.sqrt

/** Loudness per second of the 16 kHz mono PCM file (used to spot excited / funny moments). */
object AudioEnergy {
    fun perSecond(pcm: File): FloatArray {
        val secs = (pcm.length() / 32000L).toInt() + 1
        val out = FloatArray(secs)
        RandomAccessFile(pcm, "r").use { raf ->
            val buf = ByteArray(32000)
            for (s in 0 until secs) {
                val n = raf.read(buf)
                if (n <= 1) break
                var sum = 0.0
                var cnt = 0
                var i = 0
                while (i + 1 < n) {
                    val sample = (buf[i + 1].toInt() shl 8) or (buf[i].toInt() and 0xFF)
                    sum += sample.toDouble() * sample.toDouble()
                    cnt++
                    i += 2
                }
                out[s] = if (cnt > 0) sqrt(sum / cnt).toFloat() else 0f
            }
        }
        return out
    }
}
