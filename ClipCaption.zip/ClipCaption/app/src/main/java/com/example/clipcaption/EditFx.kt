package com.example.clipcaption

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import androidx.media3.common.Effect
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.Contrast
import androidx.media3.effect.MatrixTransformation
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.TextureOverlay
import kotlin.math.max

/** Punch-in zoom: the picture jumps closer at every cut point and then slowly pushes in. */
class PunchZoom(private val cuts: List<Long>, private val strong: Boolean) : MatrixTransformation {
    override fun getMatrix(presentationTimeUs: Long): Matrix {
        val t = presentationTimeUs / 1000
        var idx = -1
        for (i in cuts.indices) {
            if (cuts[i] <= t) idx = i else break
        }
        val segStart = if (idx >= 0) cuts[idx] else 0L
        val el = ((t - segStart) / 4000f).coerceIn(0f, 1f)
        val push = if (strong) 0.08f else 0.05f
        val base = if ((idx + 1) % 2 == 0) 1.0f else (if (strong) 1.16f else 1.11f)
        val s = base + push * el
        val m = Matrix()
        m.postScale(s, s)
        return m
    }
}

/** Thin progress bar that fills while the clip plays. */
class ProgressBarOverlay(
    private val durMs: Long,
    private val outW: Int,
    private val barH: Int,
    private val yNdc: Float
) : BitmapOverlay() {

    private var lastQ = -1L
    private var last: Bitmap = Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888)
    private val paint = Paint().apply { color = 0xFFFFD400.toInt() }

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val ms = presentationTimeUs / 1000
        val q = ms / 100
        if (q == lastQ) return last
        lastQ = q
        val p = (ms.toFloat() / max(1L, durMs)).coerceIn(0f, 1f)
        val bmp = Bitmap.createBitmap(outW, barH, Bitmap.Config.ARGB_8888)
        Canvas(bmp).drawRect(0f, 0f, outW * p, barH.toFloat(), paint)
        last = bmp
        return bmp
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings =
        OverlaySettings.Builder().setBackgroundFrameAnchor(0f, yNdc).build()
}

/** Fade from black at the start and to black at the end. */
class FadeOverlay(
    private val durMs: Long,
    private val outW: Int,
    private val outH: Int,
    private val inMs: Long,
    private val outMs: Long
) : BitmapOverlay() {

    private val blank: Bitmap = Bitmap.createBitmap(2, 2, Bitmap.Config.ARGB_8888)
    private var lastQ = -1
    private var last: Bitmap = blank

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val ms = presentationTimeUs / 1000
        val a = when {
            ms < inMs -> 1f - ms.toFloat() / inMs
            ms > durMs - outMs -> (ms - (durMs - outMs)).toFloat() / outMs
            else -> 0f
        }.coerceIn(0f, 1f)
        if (a < 0.03f) { lastQ = -1; last = blank; return blank }
        val q = (a * 16).toInt()
        if (q == lastQ) return last
        lastQ = q
        val bmp = Bitmap.createBitmap(outW, outH, Bitmap.Config.ARGB_8888)
        bmp.eraseColor(Color.argb((q * 255 / 16).coerceIn(0, 255), 0, 0, 0))
        last = bmp
        return bmp
    }
}

object EditFx {

    val levelNames = listOf(
        "Auto edit (zoom + pop + progress bar)",
        "Strong edit (zyada zoom + color + fade)",
        "Off (simple)"
    )

    /** Cut points for the punch zooms: caption starts, at least 2.8 s apart. */
    fun cutsFrom(caps: List<Caption>, minGapMs: Long = 2800L): List<Long> {
        val out = ArrayList<Long>()
        for (c in caps.sortedBy { it.startMs }) {
            if (out.isEmpty() || c.startMs - out.last() >= minGapMs) out.add(c.startMs)
        }
        return out
    }

    fun videoEffects(level: Int, cuts: List<Long>): List<Effect> {
        if (level >= 2) return emptyList()
        val list = ArrayList<Effect>()
        list.add(PunchZoom(cuts, level == 1))
        if (level == 1) list.add(Contrast(0.12f))
        return list
    }

    fun progressOverlay(level: Int, durMs: Long, outW: Int, outH: Int): TextureOverlay? {
        if (level >= 2) return null
        val barH = max(8, outH / 160)
        val y = -1f + 2f * (barH * 2.5f) / outH
        return ProgressBarOverlay(durMs, outW, barH, y)
    }

    fun fadeOverlay(level: Int, durMs: Long, outW: Int, outH: Int): TextureOverlay? {
        if (level != 1) return null
        return FadeOverlay(durMs, outW, outH, 150L, 300L)
    }
}
