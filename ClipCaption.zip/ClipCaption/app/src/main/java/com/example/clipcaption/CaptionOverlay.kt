package com.example.clipcaption

import android.graphics.Bitmap
import androidx.media3.effect.BitmapOverlay
import androidx.media3.effect.OverlaySettings

/** Shows the right caption bitmap for each video frame time. */
class CaptionBitmapOverlay(
    private val captions: List<Caption>,
    private val renderer: CaptionRenderer,
    private val useEmoji: Boolean,
    private val positionIdx: Int,
    private val highlight: Boolean,
    private val pop: Boolean = false
) : BitmapOverlay() {

    private val blank: Bitmap = renderer.blank()

    private val cache = object : LinkedHashMap<Int, Bitmap>(8, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Int, Bitmap>?): Boolean {
            return size > 6
        }
    }

    override fun getBitmap(presentationTimeUs: Long): Bitmap {
        val ms = presentationTimeUs / 1000
        var ci = -1
        for (i in captions.indices) {
            val c = captions[i]
            if (ms >= c.startMs && ms < c.endMs) { ci = i; break }
        }
        if (ci < 0) return blank
        val cap = captions[ci]
        var ai = -1
        if (highlight) {
            ai = 0
            for (i in cap.words.indices) if (ms >= cap.words[i].startMs) ai = i
        }
        val key = ci * 1000 + (ai + 1)
        return cache.getOrPut(key) {
            renderer.render(cap.words.map { it.text }, ai, if (useEmoji) cap.emoji else "")
        }
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        val y = when (positionIdx) {
            0 -> -0.66f
            1 -> 0f
            else -> 0.66f
        }
        val b = OverlaySettings.Builder().setBackgroundFrameAnchor(0f, y)
        if (pop) {
            val ms = presentationTimeUs / 1000
            for (c in captions) {
                if (ms >= c.startMs && ms < c.endMs) {
                    val dt = ms - c.startMs
                    if (dt < 180) {
                        val sc = popScale(dt / 180f)
                        b.setScale(sc, sc)
                    }
                    break
                }
            }
        }
        return b.build()
    }

    private fun popScale(p: Float): Float {
        val c1 = 1.70158f
        val c3 = c1 + 1f
        val x = p - 1f
        val e = 1f + c3 * x * x * x + c1 * x * x
        return 0.6f + 0.4f * e
    }
}
