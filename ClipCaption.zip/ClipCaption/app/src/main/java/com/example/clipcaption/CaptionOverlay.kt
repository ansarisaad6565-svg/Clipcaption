package com.example.clipcaption

import android.graphics.Color
import android.text.Spannable
import android.text.SpannableString
import android.text.style.AbsoluteSizeSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.TextOverlay

/** Caption times are relative to the exported clip, in microseconds. */
data class TimedCaption(val text: String, val startUs: Long, val endUs: Long)

class CaptionOverlay(
    private val captions: List<TimedCaption>,
    private val textSizePx: Int
) : TextOverlay() {

    override fun getText(presentationTimeUs: Long): SpannableString {
        val cap = captions.firstOrNull { presentationTimeUs >= it.startUs && presentationTimeUs < it.endUs }
        if (cap == null) {
            // Blank, invisible placeholder (empty text is not safe to render)
            return SpannableString(" ")
        }
        val s = SpannableString(wrap(cap.text))
        val n = s.length
        s.setSpan(ForegroundColorSpan(Color.WHITE), 0, n, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        s.setSpan(BackgroundColorSpan(0xAA000000.toInt()), 0, n, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        s.setSpan(AbsoluteSizeSpan(textSizePx, false), 0, n, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
        return s
    }

    override fun getOverlaySettings(presentationTimeUs: Long): OverlaySettings {
        // Bottom-center of the frame
        return OverlaySettings.Builder()
            .setBackgroundFrameAnchor(0f, -0.75f)
            .build()
    }

    private fun wrap(text: String, maxChars: Int = 28): String {
        val out = StringBuilder()
        var line = 0
        for (word in text.trim().split(Regex("\\s+"))) {
            if (line > 0 && line + 1 + word.length > maxChars) {
                out.append('\n'); line = 0
            } else if (line > 0) {
                out.append(' '); line++
            }
            out.append(word); line += word.length
        }
        return out.toString()
    }
}
