package com.example.clipcaption

/** Keyword -> emoji (English, Hinglish, Hindi) with stemming and spelling-variant matching. */
object EmojiMap {

    val generic = listOf("✨", "👉", "🙌", "😄", "👏", "💫", "😎", "🤩", "👌", "💯")

    private const val DATA = """
❤️ love loved loving lovely pyar pyara pyari prem dil dilse heart ishq ishk mohabbat jaan jaanu babu प्यार प्रेम दिल इश्क मोहब्बत
😍 beautiful beauty pretty gorgeous cute handsome sundar khoobsurat हसीन सुंदर खूबसूरत
😂 funny lol haha hahaha joke jokes mazak mazaak hasi hansi hasna comedy laugh laughing मज़ाक मजाक हंसी कॉमेडी
😊 happy khush khushi smile muskan मुस्कान खुश खुशी
😢 sad cry crying dukh udaas udas rona roya aansu tears रोना दुख उदास आंसू
😡 angry anger gussa gusse furious गुस्सा
😱 shocked shock scary horror darr dar daro darna डर डरावना
😴 sleep sleeping tired neend thaka thakan नींद थका
🤔 think thinking idea soch sochna vichar confused सोच विचार
🔥 fire hot lit aag mast zabardast blast dhamaka killer धमाका आग मस्त जबरदस्त
💰 money cash rich paisa paise rupee rupaye dollar dollars salary income kamai earn earning पैसा पैसे रुपया रुपये धन अमीर कमाई
💸 million billion lakh crore karod hazaar expensive mehenga spend kharcha महंगा खर्च
🏠 home house ghar makaan flat घर मकान
🍕 food pizza khana khaana khane bhook hungry eat eating dinner lunch breakfast nashta खाना भूख
☕ tea chai coffee चाय कॉफी
🍔 burger fries fastfood
🍰 cake mithai sweet dessert मिठाई केक
🎂 birthday bday janamdin जन्मदिन
🎉 party celebrate celebration congratulations congrats mubarak badhai jashn जश्न बधाई मुबारक पार्टी
🎵 music song songs gaana gana gaane sing singing singer geet गाना संगीत गाने
💃 dance dancing naach nachna nritya नाच डांस
🎬 movie film cinema movies shooting फिल्म
📹 video videos vlog reel reels shorts वीडियो
📱 phone mobile smartphone iphone android call फोन मोबाइल
💻 computer laptop coding code programming software technology tech website app application लैपटॉप
🤖 ai robot chatgpt artificial
🌐 internet online web wifi
📶 network signal
🚗 car drive driving gaadi gadi गाड़ी कार
🏍️ bike bullet motorcycle
🚆 train railway station rail
✈️ flight plane airport travel trip safar yatra holiday vacation सफर यात्रा
🌍 world duniya earth global दुनिया
🌧️ rain barish baarish monsoon बारिश
☀️ sun sunny dhoop garmi summer सूरज धूप गर्मी
❄️ cold winter sardi thand snow सर्दी ठंड
🌙 moon night raat chand रात चांद
⭐ star stars sitara tara सितारा तारा
🌹 flower flowers rose phool gulab गुलाब फूल
🐶 dog dogs kutta puppy कुत्ता
🐱 cat billi kitten बिल्ली
🐅 tiger sher शेर बाघ
🐎 horse ghoda घोड़ा
🐄 cow gaay gau गाय
🦁 lion
🐒 monkey bandar बंदर
🐦 bird chidiya panchi चिड़िया
💪 strong strength gym power workout fitness muscle taakat taqat mehnat ताकत मेहनत जिम
🏃 run running daud race दौड़
🧘 yoga meditation peace shanti calm योग शांति
🏆 win winner won victory champion jeet jeetna trophy jeeta जीत विजेता
🥇 gold medal
📚 study book books school education padhai padhna kitab padhai पढ़ाई किताब स्कूल
🎓 college university degree graduate exam exams pariksha result परीक्षा
✍️ write writing likhna likho लिखना
💼 work job office business kaam naukri vyapar startup company काम नौकरी ऑफिस बिज़नेस
👔 boss manager sir
⏰ time clock alarm deadline waqt samay timing समय वक्त
📅 date calendar schedule tarikh tareekh
👍 good great nice awesome perfect best excellent accha achha acchi badiya sahi अच्छा बढ़िया सही
👎 bad worst bura buri बुरा
🙏 please thanks thank dhanyavad shukriya namaste pranam sorry maaf thankyou धन्यवाद शुक्रिया नमस्ते माफ
👋 hello hey bye namaskar alvida नमस्कार
🤗 welcome swagat hug गले स्वागत
🤝 friend friends dost dosto deal help dosti partner madad दोस्त दोस्तों दोस्ती मदद
👪 family mother father mummy papa parivar maa baap beta beti bhai behen sister brother परिवार माँ पापा मम्मी
👶 baby child kid kids bachcha bachche bacha बच्चा बच्चे
💔 breakup heartbreak broken dhokha cheat धोखा
😎 cool swag style stylish attitude
🤩 amazing wow incredible unbelievable kamaal fantastic kamal कमाल
🚀 rocket launch growth fast success safal safalta tezi सफलता तेज
💡 learn tip tips trick hack sikho seekho sikhna idea sikh सीखो सीखना
⚠️ warning danger careful khatra savdhan khatarnak खतरा सावधान
✅ yes correct right true haan sach done complete हाँ हां सच
❌ no wrong false nahi galat mat नहीं गलत
❓ why kyun kyon question sawal सवाल
📈 profit increase growth badhna faayda fayda badhti फायदा
📉 loss decrease down nuksan nuksaan fall नुकसान
🔔 subscribe subscribed bell notification सब्सक्राइब
👍🏻 like likes लाइक
💬 comment comments chat message reply baat kehna कमेंट
🔗 link share shared शेयर
🧠 brain mind dimaag dimag smart intelligent दिमाग
👀 look watch dekho dekhna see seen dekh dekhiye देखो देखना
👂 listen sunno suno sunna hear सुनो सुनना
🗣️ speak talk bolo bolna bolta speech बोलो बोलना
😷 sick ill bimar bimari doctor medicine dawai hospital बीमार बीमारी दवाई
💊 tablet pills dawa
🕌 mosque masjid allah eid ramzan ramadan namaz मस्जिद अल्लाह ईद
🛕 temple mandir bhagwan god ram krishna shiv hanuman pooja puja prayer मंदिर भगवान राम कृष्ण शिव पूजा
🪔 diwali deepak diya dipawali दिवाली दीया
🎨 holi colors colour rang रंग होली
🎄 christmas santa
🇮🇳 india bharat hindustan indian desh भारत इंडिया हिंदुस्तान देश
🏏 cricket match ipl bat bowling batting क्रिकेट मैच
⚽ football soccer goal फुटबॉल
🏸 badminton tennis sport sports khel खेल
🎮 game games gaming gamer pubg freefire खेल
🔫 gun fight ladai war yudh लड़ाई युद्ध
💣 bomb boom
👑 king queen raja rani raaja badshah राजा रानी बादशाह
💎 diamond hira heera jewel हीरा
🌟 shine chamak bright glow चमक
🥳 surprise
🎁 gift gifts tohfa tohfe तोहफा गिफ्ट
🛍️ shopping buy sale shop kharidna kharid offer discount खरीदना
🍎 apple fruit fruits phal fal फल सेब
🥗 healthy diet salad
🏖️ beach sea samundar samandar ocean समंदर
⛰️ mountain pahad pahaad hill पहाड़
🌳 tree nature plant ped paudha environment पेड़ प्रकृति
🔒 lock secret private password raaz security safe राज
🔑 key solution chaabi
📸 photo picture camera selfie photography फोटो तस्वीर कैमरा
🎤 mic podcast interview microphone live
😅 oops mistake galti error problem pareshani गलती परेशानी
💯 very really super extremely totally bilkul bahut bohot zyada sabse hundred percent बहुत बिल्कुल सबसे
🤞 hope luck lucky umeed kismat qismat naseeb उम्मीद किस्मत नसीब
🙈 shy sharam sharmana शर्म
🤫 shh quiet chup silent चुप
🤯 mindblowing blown crazy pagal paagal पागल
🥺 miss missing yaad please याद
😘 kiss kisses chumma
💍 marriage wedding shaadi shadi married शादी
🍃 fresh hawa air हवा
💧 water paani pani drink पानी
🍽️ restaurant hotel dhaba होटल
🛒 market bazaar bazar cart बाजार
📞 contact number whatsapp
💌 email mail letter
🧾 bill invoice tax gst
🏦 bank loan emi account बैंक
📊 chart data statistics report analysis
🛠️ repair fix tool tools banana mistri
🔍 search find research khoj dhundh खोज
🎯 target goal aim focus lakshya lakshya लक्ष्य
🏁 start begin shuru finish end khatam शुरू खत्म
🌅 morning subah sunrise सुबह
🌆 evening shaam sunset शाम
🔊 loud volume awaaz sound आवाज़ आवाज
🤷 maybe shayad perhaps शायद
👆 up upar ऊपर
👇 down neeche below नीचे
➡️ next aage forward आगे
🆕 new naya nayi naye latest नया नई नए
🆓 free muft मुफ्त
💥 explosion bhaukal धमाल
🙌 hurray yay celebrate
😁 enjoy fun masti maza majaa mazaa मस्ती मज़ा
"""

    private fun norm(s: String): String {
        var t = s.lowercase().trim()
        t = t.replace("aa", "a").replace("ee", "i").replace("oo", "u")
            .replace("w", "v").replace("ph", "f").replace("z", "j").replace("q", "k")
        if (t.length > 3 && t.endsWith("s")) t = t.dropLast(1)
        return t
    }

    private fun skeleton(n: String): String {
        val sb = StringBuilder()
        for (ch in n) {
            if (ch in "aeiou") continue
            if (sb.isNotEmpty() && sb.last() == ch) continue
            sb.append(ch)
        }
        return sb.toString()
    }

    private fun romanNorm(w: String): String =
        norm(if (Translit.hasDevanagari(w)) Translit.toRoman(w) else w)

    private val exact = HashMap<String, String>()
    private val skel = HashMap<String, String>()
    private val skelBad = HashSet<String>()

    init {
        for (line in DATA.lines()) {
            val parts = line.trim().split(Regex("\\s+"))
            if (parts.size < 2) continue
            val emoji = parts[0]
            for (i in 1 until parts.size) {
                val key = parts[i]
                val k = norm(key)
                if (k.length >= 2 && !exact.containsKey(k)) exact[k] = emoji
                val rk = romanNorm(key)
                if (rk.length >= 2 && !exact.containsKey(rk)) exact[rk] = emoji
                if (rk.length >= 4) {
                    val sk = skeleton(rk)
                    if (sk.length >= 3) {
                        val prev = skel[sk]
                        if (prev == null) skel[sk] = emoji
                        else if (prev != emoji) skelBad.add(sk)
                    }
                }
            }
        }
        for (b in skelBad) skel.remove(b)
    }

    private fun lookup(n: String): String? {
        exact[n]?.let { return it }
        for (suf in listOf("ing", "ed", "es", "er", "ly")) {
            if (n.length > suf.length + 2 && n.endsWith(suf)) {
                val b = n.dropLast(suf.length)
                exact[b]?.let { return it }
                exact[b + "e"]?.let { return it }
            }
        }
        return null
    }

    /** Best emoji for one word (candidates = the same word in different scripts/spellings). */
    fun find(fuzzy: Boolean, vararg candidates: String): String? {
        for (c in candidates) {
            val cleaned = c.trim().trim('.', ',', '?', '!', ';', ':', '।', '"', '\'')
            if (cleaned.isEmpty()) continue
            val n = romanNorm(cleaned)
            lookup(n)?.let { return it }
            if (fuzzy && n.length >= 4) {
                val sk = skeleton(n)
                if (sk.length >= 3) skel[sk]?.let { return it }
            }
        }
        return null
    }
}
