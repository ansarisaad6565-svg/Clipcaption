package com.example.clipcaption

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Saves / restores the app state so the project is still there after the app is closed. */
object ProjectIo {

    fun write(ctx: Context, name: String, o: JSONObject) {
        try { File(ctx.filesDir, name).writeText(o.toString()) } catch (e: Exception) { }
    }

    fun read(ctx: Context, name: String): JSONObject? {
        val f = File(ctx.filesDir, name)
        if (!f.exists()) return null
        return try { JSONObject(f.readText()) } catch (e: Exception) { null }
    }

    fun delete(ctx: Context, name: String) {
        try { File(ctx.filesDir, name).delete() } catch (e: Exception) { }
    }

    fun canRead(ctx: Context, uri: Uri): Boolean = try {
        ctx.contentResolver.openFileDescriptor(uri, "r")?.close()
        true
    } catch (e: Exception) {
        false
    }

    fun wordsToJson(list: List<RawWord>): JSONArray {
        val a = JSONArray()
        for (w in list) a.put(JSONArray().put(w.text).put(w.startMs).put(w.endMs))
        return a
    }

    fun wordsFromJson(a: JSONArray?): List<RawWord> {
        val out = ArrayList<RawWord>()
        if (a == null) return out
        for (i in 0 until a.length()) {
            val x = a.optJSONArray(i) ?: continue
            out.add(RawWord(x.optString(0, ""), x.optLong(1, 0), x.optLong(2, 0)))
        }
        return out
    }

    fun floatsToJson(f: FloatArray?): JSONArray {
        val a = JSONArray()
        if (f != null) for (v in f) a.put(v.toDouble())
        return a
    }

    fun floatsFromJson(a: JSONArray?): FloatArray? {
        if (a == null || a.length() == 0) return null
        return FloatArray(a.length()) { a.optDouble(it, 0.0).toFloat() }
    }

    fun captionToJson(c: Caption): JSONObject =
        JSONObject().put("s", c.startMs).put("e", c.endMs).put("emoji", c.emoji)
            .put("w", wordsToJson(c.words.map { RawWord(it.text, it.startMs, it.endMs) }))

    fun captionFromJson(o: JSONObject): Caption {
        val ws = wordsFromJson(o.optJSONArray("w")).map { Word(it.text, it.startMs, it.endMs) }
        return Caption(ws, o.optString("emoji", ""), o.optLong("s", 0), o.optLong("e", 0))
    }
}
