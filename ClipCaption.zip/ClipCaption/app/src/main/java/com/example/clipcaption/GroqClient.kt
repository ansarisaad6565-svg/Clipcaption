package com.example.clipcaption

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Online AI: Whisper large-v3 for speech-to-text + an LLM for correction, spelling, emoji and clip finding (Groq free API). */
object GroqClient {

    private const val BASE = "https://api.groq.com/openai/v1"
    private const val UA = "ClipCaption/3.4 (Android)"

    const val HINGLISH_PROMPT =
        "Aaj hum ek mast video dekhenge. Kya haal hai dosto, sab theek? Yeh Hinglish hai, Roman letters me likhna: bahut accha, kaise ho bhai, chalo shuru karte hain."
    const val HINDI_PROMPT = "यह एक हिंदी वीडियो है। नमस्ते दोस्तों, आज हम कुछ नया सीखेंगे।"

    private val CHAT_MODELS = listOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant", "openai/gpt-oss-20b")

    /** Which chat models were really used (to warn when only a weaker model was available). */
    val modelsUsed = LinkedHashSet<String>()

    fun resetModels() { modelsUsed.clear() }

    class ApiException(val code: Int, message: String, val retryAfter: Int = 0) : IOException(message)

    // ---------------------------------------------------------------- speech to text

    fun transcribe(
        pcmFile: File,
        apiKey: String,
        language: String,
        prompt: String,
        status: (String) -> Unit
    ): List<RawWord> {
        try { AudioNormalize.normalize(pcmFile) } catch (e: Exception) { /* optional step */ }

        val chunkBytes = 600L * 32000L // 10 minutes per request (stays under the 25 MB limit)
        val total = pcmFile.length()
        val chunks = ((total + chunkBytes - 1) / chunkBytes).toInt().coerceAtLeast(1)
        val out = ArrayList<RawWord>()
        var offset = 0L
        var idx = 0
        var tail = ""
        RandomAccessFile(pcmFile, "r").use { raf ->
            while (offset < total) {
                val len = minOf(chunkBytes, total - offset).toInt()
                val data = ByteArray(len)
                raf.seek(offset)
                raf.readFully(data)
                status("AI Whisper se awaaz likh raha hai... (${idx + 1}/$chunks)")
                val p = if (tail.isEmpty()) prompt else (prompt + " " + tail).takeLast(700)
                val wav = wavBytes(data)
                var res = uploadRetry(wav, apiKey, language, p, status)
                if (language.isEmpty()) {
                    val dl = res.second.lowercase()
                    val fine = dl.isEmpty() || dl.startsWith("hindi") || dl.startsWith("english") || dl == "hi" || dl == "en"
                    if (!fine) {
                        status("Language galat detect hui ($dl), Hindi me dobara chala raha hoon...")
                        res = uploadRetry(wav, apiKey, "hi", prompt, status)
                    }
                }
                val words = res.first
                val offMs = offset / 32
                for (w in words) out.add(RawWord(w.text, w.startMs + offMs, w.endMs + offMs))
                tail = words.takeLast(25).joinToString(" ") { it.text }
                offset += len
                idx++
            }
        }
        return out
    }

    private fun wavBytes(pcm: ByteArray): ByteArray {
        val bb = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray())
        bb.putInt(36 + pcm.size)
        bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray())
        bb.putInt(16)
        bb.putShort(1.toShort())
        bb.putShort(1.toShort())
        bb.putInt(16000)
        bb.putInt(32000)
        bb.putShort(2.toShort())
        bb.putShort(16.toShort())
        bb.put("data".toByteArray())
        bb.putInt(pcm.size)
        bb.put(pcm)
        return bb.array()
    }

    private fun upload(wav: ByteArray, key: String, language: String, prompt: String): Pair<List<RawWord>, String> {
        val boundary = "----ClipCaption" + System.currentTimeMillis()
        val head = ByteArrayOutputStream()
        fun field(name: String, value: String) {
            head.write(
                ("--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + name + "\"\r\n\r\n" + value + "\r\n")
                    .toByteArray(Charsets.UTF_8)
            )
        }
        field("model", "whisper-large-v3")
        field("response_format", "verbose_json")
        field("timestamp_granularities[]", "word")
        field("timestamp_granularities[]", "segment")
        field("temperature", "0")
        if (language.isNotEmpty()) field("language", language)
        if (prompt.isNotEmpty()) field("prompt", prompt)
        val fileHead = ("--" + boundary + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.wav\"\r\n" +
                "Content-Type: audio/wav\r\n\r\n").toByteArray(Charsets.UTF_8)
        val tail = ("\r\n--" + boundary + "--\r\n").toByteArray(Charsets.UTF_8)
        val headBytes = head.toByteArray()
        val total = headBytes.size + fileHead.size + wav.size + tail.size

        val conn = URL("$BASE/audio/transcriptions").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 30000
            conn.readTimeout = 240000
            conn.setRequestProperty("Authorization", "Bearer $key")
            conn.setRequestProperty("User-Agent", UA)
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            conn.setFixedLengthStreamingMode(total)
            conn.outputStream.use {
                it.write(headBytes)
                it.write(fileHead)
                it.write(wav)
                it.write(tail)
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw apiError(code, body, retryHeader(conn))
            return parseWords(JSONObject(body))
        } finally {
            conn.disconnect()
        }
    }

    private fun parseWords(o: JSONObject): Pair<List<RawWord>, String> {
        val lang = o.optString("language", "")
        val out = ArrayList<RawWord>()

        // segments that are probably music / silence / repeated hallucination are dropped
        val drops = ArrayList<LongArray>()
        val segs = o.optJSONArray("segments")
        if (segs != null) {
            for (i in 0 until segs.length()) {
                val sg = segs.optJSONObject(i) ?: continue
                val noSpeech = sg.optDouble("no_speech_prob", 0.0)
                val lp = sg.optDouble("avg_logprob", 0.0)
                val cr = sg.optDouble("compression_ratio", 0.0)
                if ((noSpeech > 0.6 && lp < -0.8) || cr > 2.8) {
                    drops.add(longArrayOf((sg.optDouble("start", 0.0) * 1000).toLong(), (sg.optDouble("end", 0.0) * 1000).toLong()))
                }
            }
        }

        val arr = o.optJSONArray("words")
        if (arr != null && arr.length() > 0) {
            for (i in 0 until arr.length()) {
                val w = arr.getJSONObject(i)
                val t = w.optString("word", "").trim()
                if (t.isEmpty()) continue
                out.add(RawWord(t, (w.optDouble("start", 0.0) * 1000).toLong(), (w.optDouble("end", 0.0) * 1000).toLong()))
            }
        } else if (segs != null) {
            for (i in 0 until segs.length()) {
                val sg = segs.getJSONObject(i)
                val parts = sg.optString("text", "").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
                if (parts.isEmpty()) continue
                val st = (sg.optDouble("start", 0.0) * 1000).toLong()
                val en = (sg.optDouble("end", 0.0) * 1000).toLong()
                val step = (en - st).coerceAtLeast(parts.size * 100L) / parts.size
                parts.forEachIndexed { k, p -> out.add(RawWord(p, st + k * step, st + (k + 1) * step)) }
            }
        }
        if (drops.isNotEmpty()) {
            val kept = out.filter { w -> drops.none { d -> w.startMs >= d[0] && w.startMs < d[1] } }
            if (kept.size >= out.size * 0.4) return Pair(kept, lang)
        }
        return Pair(out, lang)
    }

    private fun retryHeader(c: HttpURLConnection): Int =
        c.getHeaderField("retry-after")?.toDoubleOrNull()?.toInt() ?: 0

    private fun apiError(code: Int, body: String, retryAfter: Int = 0): ApiException {
        val msg = try {
            JSONObject(body).optJSONObject("error")?.optString("message")
        } catch (e: Exception) {
            null
        }
        val text = when (code) {
            401 -> "API key galat hai ya expire ho gayi."
            413 -> "Request bahut badi hai."
            429 -> "Free limit poori ho gayi, thodi der baad try karo."
            else -> "Server error ($code): " + (msg ?: body.take(120))
        }
        return ApiException(code, text, retryAfter)
    }

    private fun uploadRetry(wav: ByteArray, key: String, language: String, prompt: String, status: (String) -> Unit): Pair<List<RawWord>, String> {
        var attempt = 0
        while (true) {
            try {
                return upload(wav, key, language, prompt)
            } catch (e: ApiException) {
                if (e.code != 429 || attempt >= 2) throw e
                val wait = (if (e.retryAfter > 0) e.retryAfter else 30).coerceAtMost(90)
                status("Free limit: $wait sec ruk raha hoon...")
                Thread.sleep(wait * 1000L)
                attempt++
            }
        }
    }

    // ---------------------------------------------------------------- chat with pacing (stay under the free token limit)

    private val tokenLog = HashMap<String, ArrayDeque<Pair<Long, Int>>>()

    private fun estTokens(s: String): Int {
        var dev = 0
        for (ch in s) if (ch in '\u0900'..'\u097F') dev++
        return ((s.length - dev) / 3.2 + dev * 1.0).toInt()
    }

    private fun pace(model: String, est: Int, status: (String) -> Unit) {
        val budget = when {
            model.contains("70b") -> 9000
            model.contains("8b") -> 4800
            else -> 6000
        }
        val log = tokenLog.getOrPut(model) { ArrayDeque() }
        while (true) {
            val now = System.currentTimeMillis()
            while (log.isNotEmpty() && now - log.first().first > 60_000) log.removeFirst()
            val used = log.sumOf { it.second }
            if (log.isEmpty() || used + est <= budget) return
            val wait = (60_000 - (now - log.first().first)).coerceAtLeast(1000)
            status("Free limit se bachne ke liye ${wait / 1000} sec ruk raha hoon...")
            Thread.sleep(minOf(wait, 4000L))
        }
    }

    /** Chat call that tries several models, paces itself, and waits when the free rate limit is hit. */
    fun chatSmart(key: String, system: String, user: String, status: (String) -> Unit): String {
        var last: ApiException? = null
        val est = estTokens(system) + estTokens(user) + 900
        for (m in CHAT_MODELS) {
            var attempt = 0
            while (attempt < 2) {
                try {
                    pace(m, est, status)
                    val r = chat(key, m, system, user)
                    modelsUsed.add(m)
                    return r
                } catch (e: ApiException) {
                    last = e
                    if (e.code == 401) throw e
                    if (e.code == 429) {
                        if (e.retryAfter > 100) break // daily limit of this model: try the next model
                        val wait = (if (e.retryAfter > 0) e.retryAfter else 20).coerceAtMost(70)
                        status("Free limit: $wait sec ruk raha hoon...")
                        Thread.sleep(wait * 1000L)
                        attempt++
                    } else {
                        break
                    }
                }
            }
        }
        throw last ?: ApiException(0, "AI se jawab nahi mila")
    }

    private fun chat(key: String, model: String, system: String, user: String): String {
        val body = JSONObject()
            .put("model", model)
            .put("temperature", 0.2)
            .put(
                "messages",
                JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", user))
            )
            .toString()
            .toByteArray(Charsets.UTF_8)
        val conn = URL("$BASE/chat/completions").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 30000
            conn.readTimeout = 120000
            conn.setRequestProperty("Authorization", "Bearer $key")
            conn.setRequestProperty("User-Agent", UA)
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setFixedLengthStreamingMode(body.size)
            conn.outputStream.use { it.write(body) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw apiError(code, resp, retryHeader(conn))
            val o = JSONObject(resp)
            val used = o.optJSONObject("usage")?.optInt("total_tokens", 0) ?: 0
            if (used > 0) {
                tokenLog.getOrPut(model) { ArrayDeque() }.addLast(System.currentTimeMillis() to used)
            }
            return o.getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content", "")
        } finally {
            conn.disconnect()
        }
    }

    // ---------------------------------------------------------------- accuracy: correct the transcript with context

    private fun scriptRule(langKey: String): String = when (langKey) {
        "hinglish" -> "Write in Hinglish: Hindi words in ROMAN (English) letters exactly the way people type on WhatsApp and Instagram, e.g. 'kya haal hai bhai', 'bahut accha', 'mera dil'. English words stay in English spelling (video, friend, business). NEVER use Devanagari."
        "hi" -> "Write in Hindi using Devanagari script. English words the speaker used may stay in English spelling."
        else -> "Write in English."
    }

    /**
     * Fixes spelling and script line by line using the whole sentence as context.
     * A fidelity guard keeps the original word whenever the AI changes it into something that sounds different.
     */
    fun fixWords(key: String, words: List<RawWord>, langKey: String, status: (String) -> Unit): List<RawWord> {
        if (words.isEmpty()) return words
        val groups = ArrayList<List<RawWord>>()
        var cur = ArrayList<RawWord>()
        for (w in words) {
            if (cur.isNotEmpty() && (cur.size >= 16 || w.startMs - cur.last().endMs > 900)) {
                groups.add(cur)
                cur = ArrayList()
            }
            cur.add(w)
            val last = w.text.trim().lastOrNull()
            if (last == '.' || last == '?' || last == '!' || last == '।') {
                groups.add(cur)
                cur = ArrayList()
            }
        }
        if (cur.isNotEmpty()) groups.add(cur)

        val system = "You clean up the subtitles of a short video. You get a JSON array of consecutive lines: [{\"i\":0,\"t\":\"text\"}]. " +
                "Rules: " +
                "1) Only fix spelling, script and words that were clearly misheard AND sound almost the same as what is written. NEVER replace a word with a different word, never rephrase, never translate, never add or remove words. If you are not sure, keep the original word. " +
                "2) Keep EXACTLY the same number of space-separated words in every line. Keep punctuation attached to the words as in the input. " +
                "3) " + scriptRule(langKey) + " " +
                "4) Reply with ONLY a JSON array, no explanation: [{\"i\":0,\"t\":\"fixed text\"}] with one object per input line."

        val out = ArrayList<RawWord>()
        var start = 0
        while (start < groups.size) {
            val end = minOf(start + 40, groups.size)
            status("AI captions ki spelling check kar raha hai... $end/${groups.size}")
            val arr = JSONArray()
            for (i in start until end) arr.put(JSONObject().put("i", i).put("t", groups[i].joinToString(" ") { it.text }))

            val fixed = HashMap<Int, String>()
            try {
                val content = chatSmart(key, system, arr.toString(), status)
                val s = content.indexOf('[')
                val e = content.lastIndexOf(']')
                if (s >= 0 && e > s) {
                    val ja = JSONArray(content.substring(s, e + 1))
                    for (k in 0 until ja.length()) {
                        val o = ja.optJSONObject(k) ?: continue
                        val i = o.optInt("i", -1)
                        val t = o.optString("t", "").trim()
                        if (i in start until end && t.isNotEmpty()) fixed[i] = t
                    }
                }
            } catch (e: ApiException) {
                if (e.code == 401) throw e
            } catch (e: Exception) {
            }

            for (i in start until end) {
                val g = groups[i]
                val parts = (fixed[i] ?: "").split(Regex("\\s+")).filter { it.isNotEmpty() }
                if (parts.size == g.size) {
                    g.forEachIndexed { k, w ->
                        val ref = if (langKey == "hinglish" && Translit.hasDevanagari(w.text)) Translit.toRoman(w.text) else w.text
                        val ok = TextSim.ratio(ref, parts[k]) >= 0.5
                        out.add(RawWord(if (ok) parts[k] else ref, w.startMs, w.endMs))
                    }
                } else if (langKey == "hinglish") {
                    for (w in g) out.add(RawWord(Translit.toRoman(w.text), w.startMs, w.endMs))
                } else {
                    out.addAll(g)
                }
            }
            start = end
        }
        return out
    }

    // ---------------------------------------------------------------- smart emoji on finished captions

    fun smartFix(key: String, caps: List<Caption>, langKey: String, density: Int, status: (String) -> Unit) {
        if (caps.isEmpty()) return
        val emojiRule = when (density) {
            0 -> "Give an emoji ONLY when the meaning clearly matches (about 1 caption in 4); otherwise use an empty string."
            1 -> "Give a closely related emoji to about half of the captions; otherwise use an empty string."
            else -> "Give a closely related emoji to EVERY caption."
        }
        val system = "You choose emoji for the captions of a short social-media video. " +
                "You get a JSON array of captions in order: [{\"i\":0,\"t\":\"text\"}, ...]. Do NOT change the text. " +
                emojiRule + " The emoji must match the meaning or mood of that caption; prefer common, widely supported emojis; one emoji only; avoid repeating the same emoji in consecutive captions. " +
                "Reply with ONLY a JSON array, no explanation, no markdown: [{\"i\":0,\"e\":\"🔥\"}, ...] with exactly one object per input caption."

        val batchSize = 60
        var start = 0
        while (start < caps.size) {
            val end = minOf(start + batchSize, caps.size)
            status("AI emoji chun raha hai... $end/${caps.size}")
            val arr = JSONArray()
            for (i in start until end) arr.put(JSONObject().put("i", i).put("t", caps[i].text))
            val content = chatSmart(key, system, arr.toString(), status)
            applyEmoji(content, caps, start, end)
            start = end
        }
    }

    private fun applyEmoji(content: String, caps: List<Caption>, start: Int, end: Int) {
        val s = content.indexOf('[')
        val e = content.lastIndexOf(']')
        if (s < 0 || e <= s) return
        val arr = try { JSONArray(content.substring(s, e + 1)) } catch (ex: Exception) { return }
        for (k in 0 until arr.length()) {
            val o = arr.optJSONObject(k) ?: continue
            val i = o.optInt("i", -1)
            if (i < start || i >= end) continue
            val em = cleanEmoji(o.optString("e", ""))
            if (em.isNotEmpty()) caps[i].emoji = em
        }
    }

    private fun cleanEmoji(e: String): String {
        val t = e.trim()
        if (t.isEmpty() || t.length > 16) return ""
        if (t.any { it.isLetterOrDigit() }) return ""
        return try {
            val bi = java.text.BreakIterator.getCharacterInstance()
            bi.setText(t)
            val first = bi.next()
            if (first > 0) t.substring(0, first) else t
        } catch (ex: Exception) {
            t
        }
    }
}
