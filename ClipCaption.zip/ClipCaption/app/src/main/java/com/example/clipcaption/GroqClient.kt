package com.example.clipcaption

import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.nio.ByteBuffer
import java.nio.ByteOrder

/** Online AI: Whisper large-v3 for speech-to-text + an LLM for correction, spelling, emoji and clip finding (Groq free API). */
object GroqClient {

    private const val BASE = "https://api.groq.com/openai/v1"
    private const val UA = "ClipCaption/3.4 (Android)"

    const val HINGLISH_PROMPT =
        "Aaj hum ek mast video dekhenge. Kya haal hai dosto, sab theek? Yeh Hinglish hai, Roman letters me likhna: bahut accha, kaise ho bhai, chalo shuru karte hain."
    const val HINDI_PROMPT = "यह एक हिंदी वीडियो है। नमस्ते दोस्तों, आज हम कुछ नया सीखेंगे।"

    private val CHAT_MODELS = listOf("llama-3.3-70b-versatile", "llama-3.1-8b-instant", "openai/gpt-oss-20b")

    /** Which chat models were really used (to warn when only a weaker model was available). */
    val modelsUsed = LinkedHashSet<String>()

    fun resetModels() { modelsUsed.clear() }

    class ApiException(val code: Int, message: String, val retryAfter: Int = 0) : IOException(message)

    // ---------------------------------------------------------------- speech to text

    fun transcribe(
        pcmFile: File,
        apiKey: String,
        language: String,
        prompt: String,
        status: (String) -> Unit
    ): List<RawWord> {
        try { AudioNormalize.normalize(pcmFile) } catch (e: Exception) { /* optional step */ }

        val chunkBytes = 600L * 32000L // 10 minutes per request (stays under the 25 MB limit)
        val total = pcmFile.length()
        val chunks = ((total + chunkBytes - 1) / chunkBytes).toInt().coerceAtLeast(1)
        val out = ArrayList<RawWord>()
        var offset = 0L
        var idx = 0
        var tail = ""
        RandomAccessFile(pcmFile, "r").use { raf ->
            while (offset < total) {
                val len = minOf(chunkBytes, total - offset).toInt()
                val data = ByteArray(len)
                raf.seek(offset)
                raf.readFully(data)
                status("AI Whisper se awaaz likh raha hai... (${idx + 1}/$chunks)")
                val p = if (tail.isEmpty()) prompt else (prompt + " " + tail).takeLast(700)
                val words = uploadRetry(wavBytes(data), apiKey, language, p, status)
                val offMs = offset / 32
                for (w in words) out.add(RawWord(w.text, w.startMs + offMs, w.endMs + offMs))
                tail = words.takeLast(25).joinToString(" ") { it.text }
                offset += len
                idx++
            }
        }
        return out
    }

    private fun wavBytes(pcm: ByteArray): ByteArray {
        val bb = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray())
        bb.putInt(36 + pcm.size)
        bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray())
        bb.putInt(16)
        bb.putShort(1.toShort())
        bb.putShort(1.toShort())
        bb.putInt(16000)
        bb.putInt(32000)
        bb.putShort(2.toShort())
        bb.putShort(16.toShort())
        bb.put("data".toByteArray())
        bb.putInt(pcm.size)
        bb.put(pcm)
        return bb.array()
    }

    private fun upload(wav: ByteArray, key: String, language: String, prompt: String): List<RawWord> {
        val boundary = "----ClipCaption" + System.currentTimeMillis()
        val head = ByteArrayOutputStream()
        fun field(name: String, value: String) {
            head.write(
                ("--" + boundary + "\r\nContent-Disposition: form-data; name=\"" + name + "\"\r\n\r\n" + value + "\r\n")
                    .toByteArray(Charsets.UTF_8)
            )
        }
        field("model", "whisper-large-v3")
        field("response_format", "verbose_json")
        field("timestamp_granularities[]", "word")
        field("temperature", "0")
        if (language.isNotEmpty()) field("language", language)
        if (prompt.isNotEmpty()) field("prompt", prompt)
        val fileHead = ("--" + boundary + "\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.wav\"\r\n" +
                "Content-Type: audio/wav\r\n\r\n").toByteArray(Charsets.UTF_8)
        val tail = ("\r\n--" + boundary + "--\r\n").toByteArray(Charsets.UTF_8)
        val headBytes = head.toByteArray()
        val total = headBytes.size + fileHead.size + wav.size + tail.size

        val conn = URL("$BASE/audio/transcriptions").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 30000
            conn.readTimeout = 240000
            conn.setRequestProperty("Authorization", "Bearer $key")
            conn.setRequestProperty("User-Agent", UA)
            conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")
            conn.setFixedLengthStreamingMode(total)
            conn.outputStream.use {
                it.write(headBytes)
                it.write(fileHead)
                it.write(wav)
                it.write(tail)
            }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw apiError(code, body, retryHeader(conn))
            return parseWords(JSONObject(body))
        } finally {
            conn.disconnect()
        }
    }

    private fun parseWords(o: JSONObject): List<RawWord> {
        val out = ArrayList<RawWord>()
        val arr = o.optJSONArray("words")
        if (arr != null && arr.length() > 0) {
            for (i in 0 until arr.length()) {
                val w = arr.getJSONObject(i)
                val t = w.optString("word", "").trim()
                if (t.isEmpty()) continue
                out.add(RawWord(t, (w.optDouble("start", 0.0) * 1000).toLong(), (w.optDouble("end", 0.0) * 1000).toLong()))
            }
            return out
        }
        val segs = o.optJSONArray("segments") ?: return out
        for (i in 0 until segs.length()) {
            val s = segs.getJSONObject(i)
            val parts = s.optString("text", "").trim().split(Regex("\\s+")).filter { it.isNotEmpty() }
            if (parts.isEmpty()) continue
            val st = (s.optDouble("start", 0.0) * 1000).toLong()
            val en = (s.optDouble("end", 0.0) * 1000).toLong()
            val step = (en - st).coerceAtLeast(parts.size * 100L) / parts.size
            parts.forEachIndexed { k, p -> out.add(RawWord(p, st + k * step, st + (k + 1) * step)) }
        }
        return out
    }

    private fun retryHeader(c: HttpURLConnection): Int =
        c.getHeaderField("retry-after")?.toDoubleOrNull()?.toInt() ?: 0

    private fun apiError(code: Int, body: String, retryAfter: Int = 0): ApiException {
        val msg = try {
            JSONObject(body).optJSONObject("error")?.optString("message")
        } catch (e: Exception) {
            null
        }
        val text = when (code) {
            401 -> "API key galat hai ya expire ho gayi."
            413 -> "Request bahut badi hai."
            429 -> "Free limit poori ho gayi, thodi der baad try karo."
            else -> "Server error ($code): " + (msg ?: body.take(120))
        }
        return ApiException(code, text, retryAfter)
    }

    private fun uploadRetry(wav: ByteArray, key: String, language: String, prompt: String, status: (String) -> Unit): List<RawWord> {
        var attempt = 0
        while (true) {
            try {
                return upload(wav, key, language, prompt)
            } catch (e: ApiException) {
                if (e.code != 429 || attempt >= 2) throw e
                val wait = (if (e.retryAfter > 0) e.retryAfter else 30).coerceAtMost(90)
                status("Free limit: $wait sec ruk raha hoon...")
                Thread.sleep(wait * 1000L)
                attempt++
            }
        }
    }

    // ---------------------------------------------------------------- chat with pacing (stay under the free token limit)

    private val tokenLog = HashMap<String, ArrayDeque<Pair<Long, Int>>>()

    private fun estTokens(s: String): Int {
        var dev = 0
        for (ch in s) if (ch in '\u0900'..'\u097F') dev++
        return ((s.length - dev) / 3.2 + dev * 1.0).toInt()
    }

    private fun pace(model: String, est: Int, status: (String) -> Unit) {
        val budget = when {
            model.contains("70b") -> 9000
            model.contains("8b") -> 4800
            else -> 6000
        }
        val log = tokenLog.getOrPut(model) { ArrayDeque() }
        while (true) {
            val now = System.currentTimeMillis()
            while (log.isNotEmpty() && now - log.first().first > 60_000) log.removeFirst()
            val used = log.sumOf { it.second }
            if (log.isEmpty() || used + est <= budget) return
            val wait = (60_000 - (now - log.first().first)).coerceAtLeast(1000)
            status("Free limit se bachne ke liye ${wait / 1000} sec ruk raha hoon...")
            Thread.sleep(minOf(wait, 4000L))
        }
    }

    /** Chat call that tries several models, paces itself, and waits when the free rate limit is hit. */
    fun chatSmart(key: String, system: String, user: String, status: (String) -> Unit): String {
        var last: ApiException? = null
        val est = estTokens(system) + estTokens(user) + 900
        for (m in CHAT_MODELS) {
            var attempt = 0
            while (attempt < 2) {
                try {
                    pace(m, est, status)
                    val r = chat(key, m, system, user)
                    modelsUsed.add(m)
                    return r
                } catch (e: ApiException) {
                    last = e
                    if (e.code == 401) throw e
                    if (e.code == 429) {
                        if (e.retryAfter > 100) break // daily limit of this model: try the next model
                        val wait = (if (e.retryAfter > 0) e.retryAfter else 20).coerceAtMost(70)
                        status("Free limit: $wait sec ruk raha hoon...")
                        Thread.sleep(wait * 1000L)
                        attempt++
                    } else {
                        break
                    }
                }
            }
        }
        throw last ?: ApiException(0, "AI se jawab nahi mila")
    }

    private fun chat(key: String, model: String, system: String, user: String): String {
        val body = JSONObject()
            .put("model", model)
            .put("temperature", 0.2)
            .put(
                "messages",
                JSONArray()
                    .put(JSONObject().put("role", "system").put("content", system))
                    .put(JSONObject().put("role", "user").put("content", user))
            )
            .toString()
            .toByteArray(Charsets.UTF_8)
        val conn = URL("$BASE/chat/completions").openConnection() as HttpURLConnection
        try {
            conn.requestMethod = "POST"
            conn.doOutput = true
            conn.connectTimeout = 30000
            conn.readTimeout = 120000
            conn.setRequestProperty("Authorization", "Bearer $key")
            conn.setRequestProperty("User-Agent", UA)
            conn.setRequestProperty("Content-Type", "application/json; charset=utf-8")
            conn.setFixedLengthStreamingMode(body.size)
            conn.outputStream.use { it.write(body) }
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val resp = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() } ?: ""
            if (code !in 200..299) throw apiError(code, resp, retryHeader(conn))
            val o = JSONObject(resp)
            val used = o.optJSONObject("usage")?.optInt("total_tokens", 0) ?: 0
            if (used > 0) {
                tokenLog.getOrPut(model) { ArrayDeque() }.addLast(System.currentTimeMillis() to used)
            }
            return o.getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").optString("content", "")
        } finally {
            conn.disconnect()
        }
    }

    // ---------------------------------------------------------------- accuracy: correct the transcript with context

    private fun scriptRule(langKey: String): String = when (langKey) {
        "hinglish" -> "Write in Hinglish: Hindi words in ROMAN (English) letters exactly the way people type on WhatsApp and Instagram, e.g. 'kya haal hai bhai', 'bahut accha', 'mera dil'. English words stay in English spelling (video, friend, business). NEVER use Devanagari."
        "hi" -> "Write in Hindi using Devanagari script. English words the speaker used may stay in English spelling."
        else -> "Write in English."
    }

    /** Fixes misheard words and spelling line by line, using the meaning of the whole sentence. */
    fun fixWords(key: String, words: List<RawWord>, langKey: String, status: (String) -> Unit): List<RawWord> {
        if (words.isEmpty()) return words
        val groups = ArrayList<List<RawWord>>()
        var cur = ArrayList<RawWord>()
        for (w in words) {
            if (cur.isNotEmpty() && (cur.size >= 16 || w.startMs - cur.last().endMs > 900)) {
                groups.add(cur)
                cur = ArrayList()
            }
            cur.add(w)
            val last = w.text.trim().lastOrNull()
            if (last == '.' || last == '?' || last == '!' || last == '।') {
                groups.add(cur)
                cur = ArrayList()
            }
        }
        if (cur.isNotEmpty()) groups.add(cur)

        val system = "You correct speech-recognition mistakes in the subtitles of a short video. " +
                "You get a JSON array of consecutive lines: [{\"i\":0,\"t\":\"text\"}]. " +
                "Rules: " +
                "1) Fix misheard or misspelled words using the meaning of the whole sentence and the neighbouring lines. Change only clear errors; if you are not sure, keep the original word. " +
                "2) Keep EXACTLY the same number of space-separated words in every line: never merge, split, add or remove words. Keep punctuation attached to the words as in the input. " +
                "3) " + scriptRule(langKey) + " " +
                "4) Do not translate and do not rephrase. " +
                "5) Reply with ONLY a JSON array, no explanation: [{\"i\":0,\"t\":\"fixed text\"}] with one object per input line."

        val out = ArrayList<RawWord>()
        var start = 0
        while (start < groups.size) {
            val end = minOf(start + 40, groups.size)
            status("AI captions ki spelling aur galat words theek kar raha hai... $end/${groups.size}")
            val arr = JSONArray()
            for (i in start until end) arr.put(JSONObject().put("i", i).put("t", groups[i].joinToString(" ") { it.text }))

            val fixed = HashMap<Int, String>()
            try {
                val content = chatSmart(key, system, arr.toString(), status)
                val s = content.indexOf('[')
                val e = content.lastIndexOf(']')
                if (s >= 0 && e > s) {
                    val ja = JSONArray(content.substring(s, e + 1))
                    for (k in 0 until ja.length()) {
                        val o = ja.optJSONObject(k) ?: continue
                        val i = o.optInt("i", -1)
                        val t = o.optString("t", "").trim()
                        if (i in start until end && t.isNotEmpty()) fixed[i] = t
                    }
                }
            } catch (e: ApiException) {
                if (e.code == 401) throw e
            } catch (e: Exception) {
            }

            for (i in start until end) {
                val g = groups[i]
                val t = fixed[i]
                if (t == null) { out.addAll(g); continue }
                val parts = t.split(Regex("\\s+")).filter { it.isNotEmpty() }
                if (parts.size == g.size) {
                    g.forEachIndexed { k, w -> out.add(RawWord(parts[k], w.startMs, w.endMs)) }
                } else if (parts.isNotEmpty()) {
                    val st = g.first().startMs
                    val en = g.last().endMs
                    val step = (en - st).coerceAtLeast(parts.size * 80L) / parts.size
                    parts.forEachIndexed { k, p -> out.add(RawWord(p, st + k * step, st + (k + 1) * step)) }
                } else {
                    out.addAll(g)
                }
            }
            start = end
        }
        return out
    }

    // ---------------------------------------------------------------- smart emoji on finished captions

    fun smartFix(key: String, caps: List<Caption>, langKey: String, density: Int, status: (String) -> Unit) {
        if (caps.isEmpty()) return
        val emojiRule = when (density) {
            0 -> "Give an emoji ONLY when the meaning clearly matches (about 1 caption in 4); otherwise use an empty string."
            1 -> "Give a closely related emoji to about half of the captions; otherwise use an empty string."
            else -> "Give a closely related emoji to EVERY caption."
        }
        val system = "You are a subtitle editor for short social-media videos. " +
                "You get a JSON array of captions in order: [{\"i\":0,\"t\":\"text\"}, ...]. The text came from speech recognition. " +
                "Rules: " +
                "1) Fix only obvious wrong words or spelling using the context of the neighbouring captions, but keep the SAME NUMBER OF WORDS in each caption, word for word. " +
                "2) " + scriptRule(langKey) + " " +
                "3) Do not put emoji or punctuation inside the text. " +
                "4) " + emojiRule + " The emoji must match the meaning or mood of that caption; prefer common, widely supported emojis; one emoji only; avoid repeating the same emoji in consecutive captions. " +
                "5) Reply with ONLY a JSON array, no explanation, no markdown: [{\"i\":0,\"t\":\"fixed text\",\"e\":\"🔥\"}, ...] with exactly one object per input caption."

        val batchSize = 50
        var start = 0
        while (start < caps.size) {
            val end = minOf(start + batchSize, caps.size)
            status("AI emoji aur spelling check... $end/${caps.size}")
            val arr = JSONArray()
            for (i in start until end) arr.put(JSONObject().put("i", i).put("t", caps[i].text))
            val content = chatSmart(key, system, arr.toString(), status)
            applyFix(content, caps, start, end)
            start = end
        }
    }

    private fun applyFix(content: String, caps: List<Caption>, start: Int, end: Int) {
        val s = content.indexOf('[')
        val e = content.lastIndexOf(']')
        if (s < 0 || e <= s) return
        val arr = try { JSONArray(content.substring(s, e + 1)) } catch (ex: Exception) { return }
        for (k in 0 until arr.length()) {
            val o = arr.optJSONObject(k) ?: continue
            val i = o.optInt("i", -1)
            if (i < start || i >= end) continue
            val cap = caps[i]

            val t = o.optString("t", "").trim()
            if (t.isNotEmpty() && t.length <= cap.text.length * 3 + 12) {
                val parts = t.split(Regex("\\s+")).filter { it.isNotEmpty() }
                if (parts.size == cap.words.size) {
                    cap.words = cap.words.mapIndexed { idx, w -> Word(parts[idx], w.startMs, w.endMs) }
                } else if (parts.isNotEmpty()) {
                    cap.setText(t)
                }
            }

            val em = cleanEmoji(o.optString("e", ""))
            if (em.isNotEmpty()) cap.emoji = em
        }
    }

    private fun cleanEmoji(e: String): String {
        val t = e.trim()
        if (t.isEmpty() || t.length > 16) return ""
        if (t.any { it.isLetterOrDigit() }) return ""
        return try {
            val bi = java.text.BreakIterator.getCharacterInstance()
            bi.setText(t)
            val first = bi.next()
            if (first > 0) t.substring(0, first) else t
        } catch (ex: Exception) {
            t
        }
    }
}
