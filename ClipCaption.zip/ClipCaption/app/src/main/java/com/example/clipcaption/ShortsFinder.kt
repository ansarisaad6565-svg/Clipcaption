package com.example.clipcaption

import org.json.JSONArray
import kotlin.math.max
import kotlin.math.min

/** Finds the best viral short-form moments in a long transcript. */
object ShortsFinder {

    private val HOOKS = listOf(
        "secret", "never", "mistake", "truth", "shocking", "crazy", "money", "free", "biggest", "worst",
        "best", "how to", "why", "unbelievable", "warning", "important", "must", "don't", "dont", "tip",
        "trick", "hack", "paisa", "crore", "lakh", "kabhi", "sach", "raaz", "galti", "dhokha", "sabse",
        "zabardast", "nahi karna", "seekho", "sikho", "pagal", "kamaal", "viral", "success", "fail",
        "rich", "amir", "gareeb", "life", "zindagi", "pyaar", "love", "dream", "sapna", "story", "kahani"
    )

    fun buildLines(raw: List<RawWord>): List<Line> {
        val lines = ArrayList<Line>()
        var cur = ArrayList<RawWord>()
        fun flush() {
            if (cur.isNotEmpty()) {
                lines.add(Line(cur.first().startMs, cur.last().endMs, cur.joinToString(" ") { it.text }))
                cur = ArrayList()
            }
        }
        for (w in raw) {
            if (cur.isNotEmpty() && (w.startMs - cur.last().endMs > 800 || cur.size >= 18)) flush()
            cur.add(w)
            val last = w.text.trim().lastOrNull()
            if (last == '.' || last == '?' || last == '!' || last == '।') flush()
        }
        flush()
        return lines
    }

    fun find(
        key: String,
        raw: List<RawWord>,
        durationMs: Long,
        count: Int,
        minSec: Int,
        maxSec: Int,
        langName: String,
        status: (String) -> Unit
    ): List<Moment> {
        val lines = buildLines(raw)
        if (lines.isEmpty()) return emptyList()
        val total = if (durationMs > 0) durationMs else lines.last().endMs

        var aiOk = false
        val pool = ArrayList<Moment>()
        try {
            val cands = aiCandidates(key, lines, count, minSec, maxSec, langName, status)
            for (c in cands) snap(c, lines, total, minSec, maxSec)?.let { pool.add(it) }
            aiOk = pool.isNotEmpty()
        } catch (e: GroqClient.ApiException) {
            if (e.code == 401) throw e
            status("AI analysis nahi chala (${e.message}). Local method use ho raha hai...")
        } catch (e: Exception) {
            status("AI analysis nahi chala. Local method use ho raha hai...")
        }

        var ranked: List<Moment> = pool.sortedByDescending { it.score }
        if (aiOk && pool.size > count) {
            status("Best $count shorts chun raha hoon...")
            try {
                aiRank(key, pool, lines, count, status)?.let { ranked = it }
            } catch (e: GroqClient.ApiException) {
                if (e.code == 401) throw e
            } catch (e: Exception) {
            }
        }

        val picked = pickNonOverlapping(ranked, count).toMutableList()
        if (picked.size < count) {
            val fill = heuristic(lines, total, minSec, maxSec, count * 4)
            for (m in fill) {
                if (picked.size >= count) break
                if (picked.none { overlaps(it, m) }) picked.add(m)
            }
        }
        return picked
    }

    // ---------------------------------------------------------------- AI

    private fun aiCandidates(
        key: String, lines: List<Line>, count: Int, minSec: Int, maxSec: Int,
        langName: String, status: (String) -> Unit
    ): List<Moment> {
        val windowMs = 420_000L
        val stepMs = 390_000L
        val lastEnd = lines.last().endMs
        val totalWin = ((lastEnd + stepMs - 1) / stepMs).toInt().coerceAtLeast(1)
        val perWindow = ((count * 1.6) / totalWin + 0.99).toInt().coerceIn(2, 4)

        val system = "You are an expert viral short-form video editor (YouTube Shorts, Instagram Reels, TikTok). " +
                "You get a transcript part. Each line is: start_seconds-end_seconds| spoken text. The language is " + langName + ". " +
                "Find up to " + perWindow + " best moments that work as standalone shorts of " + minSec + " to " + maxSec + " seconds. " +
                "Best moments have: a strong hook in the first 3 seconds, a complete thought or story, surprise, emotion, humor, a valuable tip, a bold opinion or high energy. " +
                "Avoid greetings, intros, outros, sponsor reads and filler. A moment must start at the beginning of a sentence and end at the end of a sentence. " +
                "Use the exact second values from the lines. Moments must not overlap. " +
                "Reply with ONLY a JSON array, no explanation, no markdown: " +
                "[{\"start\":123,\"end\":170,\"title\":\"catchy title in " + langName + " (max 8 words)\",\"score\":0-100,\"reason\":\"short reason\"}]"

        val out = ArrayList<Moment>()
        var t0 = 0L
        var wi = 0
        while (t0 < lastEnd) {
            val wl = lines.filter { it.startMs >= t0 && it.startMs < t0 + windowMs }
            wi++
            if (wl.size >= 3) {
                status("AI viral moments dhundh raha hai... ($wi/$totalWin)")
                val text = wl.joinToString("\n") { (it.startMs / 1000).toString() + "-" + (it.endMs / 1000) + "| " + it.text }
                val content = GroqClient.chatSmart(key, system, text, status)
                out.addAll(parseMoments(content))
            }
            t0 += stepMs
        }
        return out
    }

    private fun parseMoments(content: String): List<Moment> {
        val out = ArrayList<Moment>()
        val s = content.indexOf('[')
        val e = content.lastIndexOf(']')
        if (s < 0 || e <= s) return out
        val arr = try { JSONArray(content.substring(s, e + 1)) } catch (ex: Exception) { return out }
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val st = o.optDouble("start", -1.0)
            val en = o.optDouble("end", -1.0)
            if (st < 0 || en <= st) continue
            out.add(
                Moment(
                    (st * 1000).toLong(), (en * 1000).toLong(),
                    o.optString("title", "").trim(),
                    o.optInt("score", 60).coerceIn(0, 100),
                    o.optString("reason", "").trim()
                )
            )
        }
        return out
    }

    private fun aiRank(key: String, pool: List<Moment>, lines: List<Line>, count: Int, status: (String) -> Unit): List<Moment>? {
        val arr = JSONArray()
        pool.forEachIndexed { i, m ->
            val snippet = lines.filter { it.startMs >= m.startMs && it.startMs < m.endMs }
                .joinToString(" ") { it.text }.take(220)
            arr.put(
                org.json.JSONObject().put("id", i).put("score", m.score).put("title", m.title)
                    .put("reason", m.reason).put("text", snippet)
            )
        }
        val system = "You are an expert viral short-form video editor. You get candidate short clips as a JSON array. " +
                "Choose the best " + count + " clips most likely to go viral: strong hook, emotion, surprise, value; prefer variety of topics. " +
                "Reply with ONLY a JSON array of the chosen ids, best first, e.g. [3,0,5]."
        val content = GroqClient.chatSmart(key, system, arr.toString(), status)
        val s = content.indexOf('[')
        val e = content.lastIndexOf(']')
        if (s < 0 || e <= s) return null
        val ids = JSONArray(content.substring(s, e + 1))
        val out = ArrayList<Moment>()
        for (i in 0 until ids.length()) {
            val id = ids.optInt(i, -1)
            if (id in pool.indices && !out.contains(pool[id])) out.add(pool[id])
        }
        // keep the rest after the chosen ones, as backup
        for (m in pool.sortedByDescending { it.score }) if (!out.contains(m)) out.add(m)
        return out
    }

    // ---------------------------------------------------------------- local helpers

    private fun snap(m: Moment, lines: List<Line>, durationMs: Long, minSec: Int, maxSec: Int): Moment? {
        var si = lines.indexOfLast { it.startMs <= m.startMs + 700 }
        if (si < 0) si = 0
        var ei = lines.indexOfFirst { it.endMs >= m.endMs - 700 }
        if (ei < 0) ei = lines.size - 1
        if (ei < si) ei = si
        val maxMs = maxSec * 1000L
        val minMs = minSec * 1000L
        while (ei > si && lines[ei].endMs - lines[si].startMs > maxMs) ei--
        while (ei < lines.size - 1 && lines[ei].endMs - lines[si].startMs < minMs) ei++
        while (ei > si && lines[ei].endMs - lines[si].startMs > maxMs + 5000) ei--
        val start = max(0L, lines[si].startMs - 250)
        val end = min(durationMs, lines[ei].endMs + 500)
        if (end - start < 8000) return null
        return Moment(start, end, m.title, m.score, m.reason)
    }

    private fun overlaps(a: Moment, b: Moment): Boolean {
        val ov = min(a.endMs, b.endMs) - max(a.startMs, b.startMs)
        val shorter = min(a.endMs - a.startMs, b.endMs - b.startMs)
        return ov > shorter * 0.2
    }

    private fun pickNonOverlapping(list: List<Moment>, count: Int): List<Moment> {
        val out = ArrayList<Moment>()
        for (m in list) {
            if (out.size >= count) break
            if (out.none { overlaps(it, m) }) out.add(m)
        }
        return out
    }

    /** Local fallback: scores speech energy, hook words, questions/exclamations and emoji-worthy words. */
    private fun heuristic(lines: List<Line>, durationMs: Long, minSec: Int, maxSec: Int, take: Int): List<Moment> {
        val targetMs = ((minSec + maxSec) / 2) * 1000L
        val scored = ArrayList<Pair<Moment, Double>>()
        for (i in lines.indices) {
            var j = i
            while (j < lines.size - 1 && lines[j].endMs - lines[i].startMs < targetMs) j++
            val dur = (lines[j].endMs - lines[i].startMs) / 1000.0
            if (dur < minSec * 0.6) continue
            var words = 0
            var q = 0
            var kw = 0
            var emo = 0
            for (k in i..j) {
                val t = lines[k].text
                val ws = t.split(" ")
                words += ws.size
                if (t.contains('?') || t.contains('!')) q++
                val low = t.lowercase()
                for (h in HOOKS) if (low.contains(h)) kw++
                for (w in ws) if (EmojiMap.find(false, w) != null) emo++
            }
            val density = words / dur
            if (density < 1.3) continue
            val score = density * 10 + q * 2.0 + kw * 4.0 + emo * 0.7
            val start = max(0L, lines[i].startMs - 250)
            val end = min(durationMs, lines[j].endMs + 500)
            scored.add(Moment(start, end, "", 0, "Energetic speech with strong keywords") to score)
        }
        if (scored.isEmpty()) return emptyList()
        scored.sortByDescending { it.second }
        val maxS = scored.first().second
        return scored.take(take).mapIndexed { idx, (m, s) ->
            m.score = (70 + 29 * (s / maxS)).toInt()
            m.title = "Short moment " + (idx + 1)
            m
        }
    }
}
