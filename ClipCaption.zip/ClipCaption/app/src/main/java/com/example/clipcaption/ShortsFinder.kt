package com.example.clipcaption

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

/**
 * Vizard-style clip finder:
 * 1) AI scans the transcript in windows and proposes moments with Hook / Flow / Value / Trend scores,
 * 2) global ranking picks the best and most varied ones,
 * 3) every pick is refined so it opens on the hook and ends on the payoff.
 */
object ShortsFinder {

    private val HOOKS = listOf(
        "secret", "never", "mistake", "truth", "shocking", "crazy", "money", "free", "biggest", "worst",
        "best", "how to", "why", "unbelievable", "warning", "important", "must", "don't", "dont", "tip",
        "trick", "hack", "paisa", "crore", "lakh", "kabhi", "sach", "raaz", "galti", "dhokha", "sabse",
        "zabardast", "nahi karna", "seekho", "sikho", "pagal", "kamaal", "viral", "success", "fail",
        "rich", "amir", "gareeb", "life", "zindagi", "pyaar", "love", "dream", "sapna", "story", "kahani"
    )

    // ---------------------------------------------------------------- transcript lines

    fun buildLines(raw: List<RawWord>, rms: FloatArray?): List<Line> {
        val lines = ArrayList<Line>()
        var cur = ArrayList<RawWord>()
        fun flush() {
            if (cur.isNotEmpty()) {
                lines.add(Line(cur.first().startMs, cur.last().endMs, cur.joinToString(" ") { it.text }))
                cur = ArrayList()
            }
        }
        for (w in raw) {
            if (cur.isNotEmpty() && (w.startMs - cur.last().endMs > 800 || cur.size >= 18)) flush()
            cur.add(w)
            val last = w.text.trim().lastOrNull()
            if (last == '.' || last == '?' || last == '!' || last == '।') flush()
        }
        flush()
        if (rms == null || rms.isEmpty() || lines.size < 8) return lines

        val avgs = lines.map { l ->
            val s = (l.startMs / 1000).toInt().coerceIn(0, rms.size - 1)
            val e = (l.endMs / 1000).toInt().coerceIn(s, rms.size - 1)
            var sum = 0f
            for (i in s..e) sum += rms[i]
            sum / (e - s + 1)
        }
        val sorted = avgs.sorted()
        val thr = sorted[(sorted.size * 0.75).toInt().coerceAtMost(sorted.size - 1)]
        if (thr <= 0f) return lines
        return lines.mapIndexed { i, l -> if (avgs[i] > thr) l.copy(loud = true) else l }
    }

    private fun fmtLine(l: Line): String =
        (l.startMs / 1000).toString() + "-" + (l.endMs / 1000) + "|" + (if (l.loud) "*" else " ") + l.text

    // ---------------------------------------------------------------- main entry

    fun find(
        key: String,
        raw: List<RawWord>,
        rms: FloatArray?,
        durationMs: Long,
        count: Int,
        minSec: Int,
        maxSec: Int,
        langName: String,
        status: (String) -> Unit
    ): List<Moment> {
        val lines = buildLines(raw, rms)
        if (lines.isEmpty()) return emptyList()
        val total = if (durationMs > 0) durationMs else lines.last().endMs

        var aiOk = false
        val pool = ArrayList<Moment>()
        try {
            val cands = aiCandidates(key, lines, total, count, minSec, maxSec, langName, status)
            for (c in cands) snap(c, lines, total, minSec, maxSec)?.let { pool.add(it) }
            aiOk = pool.isNotEmpty()
        } catch (e: GroqClient.ApiException) {
            if (e.code == 401) throw e
            status("AI analysis nahi chala (" + e.message + "). Local method use ho raha hai...")
        } catch (e: Exception) {
            status("AI analysis nahi chala. Local method use ho raha hai...")
        }

        var ranked: List<Moment> = pool.sortedByDescending { it.score }
        if (aiOk && pool.size > count) {
            status("Poori video me se sabse viral $count clips chun raha hoon...")
            try {
                aiRank(key, pool, lines, count, total, status)?.let { ranked = it }
            } catch (e: GroqClient.ApiException) {
                if (e.code == 401) throw e
            } catch (e: Exception) {
            }
        }

        // pick best clips but spread them over the whole video (beginning, middle and end)
        val picked = selectSpread(ranked, count, total).toMutableList()

        // make sure we really get `count` clips
        if (picked.size < count) {
            status("Aur achhe moments dhundh raha hoon...")
            val fill = heuristic(lines, total, minSec, maxSec, count * 8, 0L, Long.MAX_VALUE, true)
            for (m in selectSpread(fill, count * 2, total)) {
                if (picked.size >= count) break
                if (picked.none { overlaps(it, m) }) picked.add(m)
            }
        }
        if (picked.size < count) uniformFill(lines, total, minSec, maxSec, count, picked)

        if (aiOk) {
            for ((i, m) in picked.withIndex()) {
                status("Clip " + (i + 1) + "/" + picked.size + " ka start/end perfect kar raha hoon...")
                try {
                    aiRefine(key, m, lines, total, minSec, maxSec, langName, status)?.let { picked[i] = it }
                } catch (e: GroqClient.ApiException) {
                    if (e.code == 401) throw e
                } catch (e: Exception) {
                }
            }
        }
        return picked.sortedByDescending { it.score }
    }

    /** Best-first list, but clips must not overlap and starts must be spread out over the video. */
    private fun selectSpread(ranked: List<Moment>, count: Int, total: Long): List<Moment> {
        val out = ArrayList<Moment>()
        val gap = max(60_000L, total / (count * 2L))
        for (m in ranked) {
            if (out.size >= count) break
            if (out.none { overlaps(it, m) || Math.abs(it.startMs - m.startMs) < gap }) out.add(m)
        }
        if (out.size < count) {
            for (m in ranked) {
                if (out.size >= count) break
                if (!out.contains(m) && out.none { overlaps(it, m) }) out.add(m)
            }
        }
        return out
    }

    /** Last resort: one clip from each equal part of the video. */
    private fun uniformFill(
        lines: List<Line>, total: Long, minSec: Int, maxSec: Int, count: Int, picked: MutableList<Moment>
    ) {
        val target = ((minSec + maxSec) / 2) * 1000L
        for (b in 0 until count * 2) {
            if (picked.size >= count) break
            val center = ((b + 0.5) * total / (count * 2)).toLong()
            val idx = lines.indexOfFirst { it.startMs >= center }.let { if (it < 0) lines.size - 1 else it }
            val st = lines[idx].startMs
            val cand = snap(Moment(st, min(total, st + target), "", 50, ""), lines, total, minSec, maxSec) ?: continue
            if (cand.hook.isEmpty()) cand.hook = lines[idx].text.take(80)
            cand.title = "Short moment " + (picked.size + 1)
            if (picked.none { overlaps(it, cand) }) picked.add(cand)
        }
    }

    // ---------------------------------------------------------------- AI: candidates

    private fun aiCandidates(
        key: String, lines: List<Line>, total: Long, count: Int, minSec: Int, maxSec: Int,
        langName: String, status: (String) -> Unit
    ): List<Moment> {
        val windowMs = 300_000L
        val stepMs = 270_000L
        val lastEnd = max(lines.last().endMs, total)
        val totalWin = ((lastEnd + stepMs - 1) / stepMs).toInt().coerceAtLeast(1)
        val perWindow = ((count * 2.5) / totalWin + 0.99).toInt().coerceIn(2, 4)
        val totalMin = (lastEnd / 60000).toInt() + 1

        val out = ArrayList<Moment>()
        var t0 = 0L
        var wi = 0
        var failed = 0
        while (t0 < lastEnd) {
            val t1 = min(lastEnd, t0 + windowMs)
            val wl = lines.filter { it.startMs >= t0 && it.startMs < t1 }
            wi++
            if (wl.size >= 3) {
                status("AI viral moments dhundh raha hai... ($wi/$totalWin)")
                val system = "You are a Vizard-style AI clipper that finds the most viral moments in long videos for YouTube Shorts, Instagram Reels and TikTok. " +
                        "The transcript below is only one part of the video: it covers minute " + (t0 / 60000) + " to minute " + (t1 / 60000) + " of a " + totalMin + "-minute video. " +
                        "Find the best moments of THIS part. The beginning, the middle and the end of a video are equally valid: do not favour conclusions, summaries or outros, and always return at least " + min(2, perWindow) + " moments if the part has any decent content. " +
                        "Each row is: start_seconds-end_seconds|text. A * right after the | means high vocal energy (laughter, excitement, emphasis). Language: " + langName + ". " +
                        "Return up to " + perWindow + " moments, each " + minSec + " to " + maxSec + " seconds long. " +
                        "Judge every moment on four scores from 0 to 10: " +
                        "HOOK (do the first 3 seconds grab attention: bold claim, question, surprising fact, strong emotion, cliffhanger), " +
                        "FLOW (a complete idea or story with a clear beginning and a satisfying ending, understandable without outside context, never starts or ends mid-thought, no references like 'as I said earlier'), " +
                        "VALUE (useful tip, insight, laugh, emotional or entertaining payoff), " +
                        "TREND (relatable, shareable, emotional or controversial topic that people comment on). " +
                        "Be honest and strict with the scores so the best moments clearly stand out. " +
                        "Skip greetings, intros, outros, sponsor reads, small talk and filler. " +
                        "Start exactly at the first line of the hook and end exactly at the end of the last line of the payoff. Use exact second values from the rows. Moments must not overlap. " +
                        "Reply with ONLY a JSON array, no explanation, no markdown: " +
                        "[{\"start\":123,\"end\":170,\"title\":\"catchy title, max 8 words\",\"hook\":\"the opening hook idea, max 12 words\"," +
                        "\"description\":\"1-2 sentence social media caption with 2-3 emojis\",\"hashtags\":[\"#tag1\",\"#tag2\",\"#tag3\"]," +
                        "\"hookScore\":8,\"flowScore\":7,\"valueScore\":9,\"trendScore\":6,\"reason\":\"why it can go viral, short\"}]. " +
                        "Write title, hook, description and reason in " + langName + "."
                try {
                    val text = wl.joinToString("\n") { fmtLine(it) }
                    val content = GroqClient.chatSmart(key, system, text, status)
                    val got = parseMoments(content)
                    if (got.isEmpty()) {
                        out.addAll(heuristic(lines, lastEnd, minSec, maxSec, 1, t0, t1, true))
                    } else {
                        out.addAll(got)
                    }
                } catch (e: GroqClient.ApiException) {
                    if (e.code == 401) throw e
                    failed++
                    out.addAll(heuristic(lines, lastEnd, minSec, maxSec, perWindow, t0, t1, true))
                } catch (e: Exception) {
                    failed++
                    out.addAll(heuristic(lines, lastEnd, minSec, maxSec, perWindow, t0, t1, true))
                }
            }
            t0 += stepMs
        }
        if (out.isEmpty()) throw GroqClient.ApiException(0, "AI se jawab nahi mila")
        return out
    }

    private fun parseMoments(content: String): List<Moment> {
        val out = ArrayList<Moment>()
        val s = content.indexOf('[')
        val e = content.lastIndexOf(']')
        if (s < 0 || e <= s) return out
        val arr = try { JSONArray(content.substring(s, e + 1)) } catch (ex: Exception) { return out }
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val st = o.optDouble("start", -1.0)
            val en = o.optDouble("end", -1.0)
            if (st < 0 || en <= st) continue
            val h = o.optInt("hookScore", 0).coerceIn(0, 10)
            val f = o.optInt("flowScore", 0).coerceIn(0, 10)
            val v = o.optInt("valueScore", 0).coerceIn(0, 10)
            val t = o.optInt("trendScore", 0).coerceIn(0, 10)
            val overall = if (h > 0 && f > 0 && v > 0 && t > 0)
                Math.round(h * 3.5 + f * 2.5 + v * 2.5 + t * 1.5).toInt()
            else o.optInt("score", 60)

            var tags = ""
            val ta = o.optJSONArray("hashtags")
            if (ta != null) {
                val list = ArrayList<String>()
                for (k in 0 until ta.length()) {
                    val x = ta.optString(k, "").trim()
                    if (x.isNotEmpty()) list.add(if (x.startsWith("#")) x else "#$x")
                }
                tags = list.joinToString(" ")
            } else {
                tags = o.optString("hashtags", "").trim()
            }

            out.add(
                Moment(
                    (st * 1000).toLong(), (en * 1000).toLong(),
                    o.optString("title", "").trim(),
                    overall.coerceIn(0, 100),
                    o.optString("reason", "").trim(),
                    true,
                    o.optString("hook", "").trim(),
                    o.optString("description", "").trim(),
                    tags, h, f, v, t
                )
            )
        }
        return out
    }

    // ---------------------------------------------------------------- AI: ranking + refining

    private fun aiRank(
        key: String, pool: List<Moment>, lines: List<Line>, count: Int, total: Long, status: (String) -> Unit
    ): List<Moment>? {
        val arr = JSONArray()
        pool.forEachIndexed { i, m ->
            val snippet = lines.filter { it.startMs >= m.startMs && it.startMs < m.endMs }
                .joinToString(" ") { it.text }.take(200)
            arr.put(
                JSONObject().put("id", i).put("minute", (m.startMs / 60000).toInt()).put("score", m.score)
                    .put("title", m.title).put("hook", m.hook).put("text", snippet)
            )
        }
        val system = "You are an expert viral short-form video editor. The source video is " + (total / 60000 + 1) + " minutes long. " +
                "You get candidate clips as a JSON array; 'minute' is where the clip starts in the video. " +
                "Choose the best " + count + " clips most likely to go viral: strong hook, emotion, surprise, value, shareability. " +
                "Spread your choice across the whole video (beginning, middle and end): never choose more than 2 clips from the same 5-minute stretch unless the others are clearly weak. " +
                "Prefer a variety of topics and avoid near-duplicate ideas. " +
                "Reply with ONLY a JSON array of the chosen ids, best first, e.g. [3,0,5]."
        val content = GroqClient.chatSmart(key, system, arr.toString(), status)
        val s = content.indexOf('[')
        val e = content.lastIndexOf(']')
        if (s < 0 || e <= s) return null
        val ids = JSONArray(content.substring(s, e + 1))
        val out = ArrayList<Moment>()
        for (i in 0 until ids.length()) {
            val id = ids.optInt(i, -1)
            if (id in pool.indices && !out.contains(pool[id])) out.add(pool[id])
        }
        for (m in pool.sortedByDescending { it.score }) if (!out.contains(m)) out.add(m)
        return out
    }

    private fun aiRefine(
        key: String, m: Moment, lines: List<Line>, total: Long,
        minSec: Int, maxSec: Int, langName: String, status: (String) -> Unit
    ): Moment? {
        val from = m.startMs - 30_000
        val to = m.endMs + 30_000
        val ctx = lines.filter { it.startMs in from..to }
        if (ctx.size < 3) return null
        val system = "You are a viral short-form video editor. Below are transcript lines (start_seconds-end_seconds|text, * = high energy) around a candidate clip that currently runs from second " +
                (m.startMs / 1000) + " to " + (m.endMs / 1000) + ". " +
                "Choose the final start and end so the clip opens on its strongest hook line, is understandable without other context, and ends right after the payoff or conclusion, never mid-sentence. " +
                "Length must be between " + minSec + " and " + maxSec + " seconds. Use exact second values from the lines. Language: " + langName + ". " +
                "Reply with ONLY JSON: {\"start\":123,\"end\":170}"
        val content = GroqClient.chatSmart(key, system, ctx.joinToString("\n") { fmtLine(it) }, status)
        val s = content.indexOf('{')
        val e = content.lastIndexOf('}')
        if (s < 0 || e <= s) return null
        val o = JSONObject(content.substring(s, e + 1))
        val st = o.optDouble("start", -1.0)
        val en = o.optDouble("end", -1.0)
        if (st < 0 || en <= st) return null
        val cand = snap(m.copyWith((st * 1000).toLong(), (en * 1000).toLong()), lines, total, minSec, maxSec) ?: return null
        val ov = min(cand.endMs, m.endMs) - max(cand.startMs, m.startMs)
        if (ov < (m.endMs - m.startMs) * 0.4) return null
        return cand
    }

    // ---------------------------------------------------------------- local helpers

    private fun snap(m: Moment, lines: List<Line>, durationMs: Long, minSec: Int, maxSec: Int): Moment? {
        var si = lines.indexOfLast { it.startMs <= m.startMs + 700 }
        if (si < 0) si = 0
        var ei = lines.indexOfFirst { it.endMs >= m.endMs - 700 }
        if (ei < 0) ei = lines.size - 1
        if (ei < si) ei = si
        val maxMs = maxSec * 1000L
        val minMs = minSec * 1000L
        while (ei > si && lines[ei].endMs - lines[si].startMs > maxMs) ei--
        while (ei < lines.size - 1 && lines[ei].endMs - lines[si].startMs < minMs) ei++
        while (ei > si && lines[ei].endMs - lines[si].startMs > maxMs + 5000) ei--
        val start = max(0L, lines[si].startMs - 250)
        val end = min(durationMs, lines[ei].endMs + 500)
        if (end - start < 8000) return null
        return m.copyWith(start, end)
    }

    private fun overlaps(a: Moment, b: Moment): Boolean {
        val ov = min(a.endMs, b.endMs) - max(a.startMs, b.startMs)
        val shorter = min(a.endMs - a.startMs, b.endMs - b.startMs)
        return ov > shorter * 0.2
    }

    private fun pickNonOverlapping(list: List<Moment>, count: Int): List<Moment> {
        val out = ArrayList<Moment>()
        for (m in list) {
            if (out.size >= count) break
            if (out.none { overlaps(it, m) }) out.add(m)
        }
        return out
    }

    /** Local fallback: scores speech energy, hook words, questions/exclamations and loud lines. */
    private fun heuristic(
        lines: List<Line>, durationMs: Long, minSec: Int, maxSec: Int, take: Int,
        from: Long, to: Long, relaxed: Boolean
    ): List<Moment> {
        val targetMs = ((minSec + maxSec) / 2) * 1000L
        val minDensity = if (relaxed) 0.6 else 1.3
        val minDur = if (relaxed) minSec * 0.4 else minSec * 0.6
        val scored = ArrayList<Pair<Moment, Double>>()
        for (i in lines.indices) {
            if (lines[i].startMs < from || lines[i].startMs >= to) continue
            var j = i
            while (j < lines.size - 1 && lines[j].endMs - lines[i].startMs < targetMs) j++
            val dur = (lines[j].endMs - lines[i].startMs) / 1000.0
            if (dur < minDur) continue
            var words = 0
            var q = 0
            var kw = 0
            var loud = 0
            for (k in i..j) {
                val t = lines[k].text
                words += t.split(" ").size
                if (t.contains('?') || t.contains('!')) q++
                val low = t.lowercase()
                for (h in HOOKS) if (low.contains(h)) kw++
                if (lines[k].loud) loud++
            }
            val density = words / dur
            if (density < minDensity) continue
            val score = density * 10 + q * 2.0 + kw * 4.0 + loud * 3.0
            val start = max(0L, lines[i].startMs - 250)
            val end = min(durationMs, lines[j].endMs + 500)
            val m = Moment(start, end, "", 0, "Energetic speech with strong keywords")
            m.hook = lines[i].text.take(80)
            scored.add(m to score)
        }
        if (scored.isEmpty()) return emptyList()
        scored.sortByDescending { it.second }
        val maxS = scored.first().second
        return scored.take(take).mapIndexed { idx, (m, s) ->
            m.score = (45 + 29 * (s / maxS)).toInt()
            m.title = "Short moment " + (idx + 1)
            m
        }
    }
}
