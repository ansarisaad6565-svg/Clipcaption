package com.example.clipcaption

import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

/**
 * Vizard-style clip finder.
 * 1) The transcript is cut into numbered lines. AI scans it in windows and picks start/end LINE numbers
 *    (so clips always begin and end exactly on a sentence) with Hook / Flow / Value / Trend scores.
 * 2) Global ranking picks the best and most varied moments, spread over the whole video.
 * 3) An "editor pass" re-reads every chosen clip with its surrounding lines, fixes the start/end,
 *    writes the final title / hook / description / hashtags and rejects clips that are weak or incomplete.
 */
object ShortsFinder {

    private val HOOKS = listOf(
        "secret", "never", "mistake", "truth", "shocking", "crazy", "money", "free", "biggest", "worst",
        "best", "how to", "why", "unbelievable", "warning", "important", "must", "don't", "dont", "tip",
        "trick", "hack", "paisa", "crore", "lakh", "kabhi", "sach", "raaz", "galti", "dhokha", "sabse",
        "zabardast", "nahi karna", "seekho", "sikho", "pagal", "kamaal", "viral", "success", "fail",
        "rich", "amir", "gareeb", "life", "zindagi", "pyaar", "love", "dream", "sapna", "story", "kahani"
    )

    // ---------------------------------------------------------------- transcript lines

    private fun wordCount(s: String): Int = s.trim().split(" ").count { it.isNotEmpty() }

    fun buildLines(raw: List<RawWord>, rms: FloatArray?, toRoman: Boolean = false): List<Line> {
        val base = ArrayList<Line>()
        var cur = ArrayList<RawWord>()
        fun flush() {
            if (cur.isNotEmpty()) {
                base.add(Line(cur.first().startMs, cur.last().endMs, cur.joinToString(" ") { if (toRoman) Translit.toRoman(it.text) else it.text }))
                cur = ArrayList()
            }
        }
        for (w in raw) {
            if (cur.isNotEmpty() && (w.startMs - cur.last().endMs > 800 || cur.size >= 22)) flush()
            cur.add(w)
            val last = w.text.trim().lastOrNull()
            if (last == '.' || last == '?' || last == '!' || last == '।') flush()
        }
        flush()

        // merge very short lines into their neighbour so every line is a meaningful unit
        val lines = ArrayList<Line>()
        for (l in base) {
            val prev = lines.lastOrNull()
            if (prev != null && wordCount(prev.text) < 5 && l.startMs - prev.endMs < 1500 && wordCount(prev.text) + wordCount(l.text) <= 30) {
                lines[lines.size - 1] = Line(prev.startMs, l.endMs, prev.text + " " + l.text)
            } else {
                lines.add(l)
            }
        }
        if (rms == null || rms.isEmpty() || lines.size < 8) return lines

        val avgs = lines.map { l ->
            val s = (l.startMs / 1000).toInt().coerceIn(0, rms.size - 1)
            val e = (l.endMs / 1000).toInt().coerceIn(s, rms.size - 1)
            var sum = 0f
            for (i in s..e) sum += rms[i]
            sum / (e - s + 1)
        }
        val sorted = avgs.sorted()
        val thr = sorted[(sorted.size * 0.75).toInt().coerceAtMost(sorted.size - 1)]
        if (thr <= 0f) return lines
        return lines.mapIndexed { i, l -> if (avgs[i] > thr) l.copy(loud = true) else l }
    }

    /** Row format for the AI: id|seconds|text  (a * before the text = high vocal energy). */
    private fun row(i: Int, l: Line): String {
        val sec = max(1L, Math.round((l.endMs - l.startMs) / 1000.0))
        return i.toString() + "|" + sec + "|" + (if (l.loud) "*" else "") + l.text
    }

    private fun overall(h: Int, f: Int, v: Int, t: Int): Int =
        Math.round(h * 3.5 + f * 2.5 + v * 2.5 + t * 1.5).toInt().coerceIn(0, 100)

    // ---------------------------------------------------------------- main entry

    fun find(
        key: String,
        raw: List<RawWord>,
        rms: FloatArray?,
        durationMs: Long,
        count: Int,
        minSec: Int,
        maxSec: Int,
        langName: String,
        toRoman: Boolean,
        status: (String) -> Unit
    ): List<Moment> {
        val lines = buildLines(raw, rms, toRoman)
        if (lines.isEmpty()) return emptyList()
        val total = if (durationMs > 0) durationMs else lines.last().endMs
        val gap = max(60_000L, total / (count * 2L))

        // 1) candidates from every part of the video
        var aiOk = false
        val pool = ArrayList<Moment>()
        try {
            val cands = aiCandidates(key, lines, total, count, minSec, maxSec, langName, status)
            for (c in cands) snap(c, lines, total, minSec, maxSec)?.let { pool.add(it) }
            aiOk = pool.isNotEmpty()
        } catch (e: GroqClient.ApiException) {
            if (e.code == 401) throw e
            status("AI analysis nahi chala (" + e.message + "). Local method use ho raha hai...")
        } catch (e: Exception) {
            status("AI analysis nahi chala. Local method use ho raha hai...")
        }

        // 2) global ranking
        var ranked: List<Moment> = pool.sortedByDescending { it.score }
        if (aiOk && pool.size > count) {
            status("Poori video me se sabse viral clips chun raha hoon...")
            try {
                aiRank(key, pool, lines, count * 2, total, status)?.let { ranked = it }
            } catch (e: GroqClient.ApiException) {
                if (e.code == 401) throw e
            } catch (e: Exception) {
            }
        }
        val order = selectSpread(ranked, count * 2, gap)

        // 3) editor pass: refine + judge each candidate until we have enough good ones
        val accepted = ArrayList<Moment>()
        var editCalls = 0
        for (cand in order) {
            if (accepted.size >= count) break
            if (accepted.any { overlaps(it, cand) }) continue
            var f: Moment? = cand
            if (aiOk && editCalls < count * 2 + 2) {
                editCalls++
                status("Clip check ho raha hai... (" + accepted.size + "/" + count + " pakke)")
                f = try {
                    aiEdit(key, cand, lines, total, minSec, maxSec, langName, status)
                } catch (e: GroqClient.ApiException) {
                    if (e.code == 401) throw e
                    cand
                } catch (e: Exception) {
                    cand
                }
            }
            val fin = f ?: continue
            if (accepted.none { overlaps(it, fin) }) accepted.add(fin)
        }

        // 4) make sure we really return `count` clips
        if (accepted.size < count) {
            for (m in ranked) {
                if (accepted.size >= count) break
                if (accepted.none { overlaps(it, m) }) accepted.add(m)
            }
        }
        if (accepted.size < count) {
            status("Aur achhe moments dhundh raha hoon...")
            for (m in heuristic(lines, total, minSec, maxSec, count * 8, 0L, Long.MAX_VALUE, true)) {
                if (accepted.size >= count) break
                if (accepted.none { overlaps(it, m) }) accepted.add(m)
            }
        }
        if (accepted.size < count) uniformFill(lines, total, minSec, maxSec, count, accepted)

        return accepted.sortedByDescending { it.score }
    }

    /** Best-first list, but clips must not overlap and their starts must be spread out over the video. */
    private fun selectSpread(ranked: List<Moment>, limit: Int, gap: Long): List<Moment> {
        val out = ArrayList<Moment>()
        for (m in ranked) {
            if (out.size >= limit) break
            if (out.none { overlaps(it, m) || Math.abs(it.startMs - m.startMs) < gap }) out.add(m)
        }
        if (out.size < limit) {
            for (m in ranked) {
                if (out.size >= limit) break
                if (!out.contains(m) && out.none { overlaps(it, m) }) out.add(m)
            }
        }
        return out
    }

    /** Last resort: one clip from each equal part of the video. */
    private fun uniformFill(
        lines: List<Line>, total: Long, minSec: Int, maxSec: Int, count: Int, picked: MutableList<Moment>
    ) {
        val target = ((minSec + maxSec) / 2) * 1000L
        for (b in 0 until count * 2) {
            if (picked.size >= count) break
            val center = ((b + 0.5) * total / (count * 2)).toLong()
            val idx = lines.indexOfFirst { it.startMs >= center }.let { if (it < 0) lines.size - 1 else it }
            val st = lines[idx].startMs
            val cand = snap(Moment(st, min(total, st + target), "", 50, ""), lines, total, minSec, maxSec) ?: continue
            if (cand.hook.isEmpty()) cand.hook = lines[idx].text.take(80)
            cand.title = "Short moment " + (picked.size + 1)
            if (picked.none { overlaps(it, cand) }) picked.add(cand)
        }
    }

    // ---------------------------------------------------------------- AI: candidates

    private fun aiCandidates(
        key: String, lines: List<Line>, total: Long, count: Int, minSec: Int, maxSec: Int,
        langName: String, status: (String) -> Unit
    ): List<Moment> {
        val windowMs = 360_000L
        val stepMs = 300_000L
        val lastEnd = max(lines.last().endMs, total)
        val totalWin = ((lastEnd + stepMs - 1) / stepMs).toInt().coerceAtLeast(1)
        val perWindow = ((count * 3.0) / totalWin + 0.99).toInt().coerceIn(3, 5)
        val totalMin = (lastEnd / 60000).toInt() + 1

        val out = ArrayList<Moment>()
        var t0 = 0L
        var wi = 0
        while (t0 < lastEnd) {
            val t1 = min(lastEnd, t0 + windowMs)
            val ids = lines.indices.filter { lines[it].startMs >= t0 && lines[it].startMs < t1 }
            wi++
            if (ids.size >= 3) {
                status("AI viral moments dhundh raha hai... ($wi/$totalWin)")
                val system = "You are a Vizard-style AI clipper that finds the most viral moments in long videos for YouTube Shorts, Instagram Reels and TikTok. " +
                        "The transcript below is only one part of the video: minute " + (t0 / 60000) + " to minute " + (t1 / 60000) + " of a " + totalMin + "-minute video. " +
                        "Find the best moments of THIS part. The beginning, middle and end of a video are equally valid; do not favour conclusions, summaries or outros. Return at least 2 moments if the part has any decent content. " +
                        "Each row is: line_id|seconds|text. A * at the start of the text means high vocal energy (laughter, excitement, emphasis). Language: " + langName + ". " +
                        "A moment is a run of consecutive lines from startLine to endLine whose total length is " + minSec + " to " + maxSec + " seconds (add up the seconds column). " +
                        "Return up to " + perWindow + " moments. Judge each on four scores from 0 to 10: " +
                        "HOOK (the first line grabs attention within 3 seconds: bold claim, question, surprising fact, strong emotion, cliffhanger), " +
                        "FLOW (a complete idea or story with a clear beginning and a satisfying ending; understandable with NO outside context; the startLine must open a thought, never continue one; the endLine must finish it; no references like 'as I said earlier' or 'this one'), " +
                        "VALUE (useful tip, insight, laugh, emotional or entertaining payoff), " +
                        "TREND (relatable, shareable, emotional or controversial). Be honest and strict so the best moments clearly stand out. " +
                        "Skip greetings, intros, outros, sponsor reads, small talk and filler. Moments must not overlap. " +
                        "Reply with ONLY a JSON array, no explanation, no markdown: " +
                        "[{\"startLine\":12,\"endLine\":19,\"title\":\"catchy title, max 8 words\",\"hook\":\"the opening hook idea, max 12 words\"," +
                        "\"hookScore\":8,\"flowScore\":7,\"valueScore\":9,\"trendScore\":6,\"reason\":\"why it can go viral, short\"}]. " +
                        "Write title, hook and reason in " + langName + "."
                try {
                    val text = ids.joinToString("\n") { row(it, lines[it]) }
                    val content = GroqClient.chatSmart(key, system, text, status)
                    val got = parseMoments(content, lines)
                    if (got.isEmpty()) {
                        out.addAll(heuristic(lines, lastEnd, minSec, maxSec, 1, t0, t1, true))
                    } else {
                        out.addAll(got)
                    }
                } catch (e: GroqClient.ApiException) {
                    if (e.code == 401) throw e
                    out.addAll(heuristic(lines, lastEnd, minSec, maxSec, perWindow, t0, t1, true))
                } catch (e: Exception) {
                    out.addAll(heuristic(lines, lastEnd, minSec, maxSec, perWindow, t0, t1, true))
                }
            }
            t0 += stepMs
        }
        if (out.isEmpty()) throw GroqClient.ApiException(0, "AI se jawab nahi mila")
        return out
    }

    private fun parseTags(o: JSONObject): String {
        val ta = o.optJSONArray("hashtags")
        if (ta != null) {
            val list = ArrayList<String>()
            for (k in 0 until ta.length()) {
                val x = ta.optString(k, "").trim()
                if (x.isNotEmpty()) list.add(if (x.startsWith("#")) x else "#$x")
            }
            return list.joinToString(" ")
        }
        return o.optString("hashtags", "").trim()
    }

    private fun parseMoments(content: String, lines: List<Line>): List<Moment> {
        val out = ArrayList<Moment>()
        val s = content.indexOf('[')
        val e = content.lastIndexOf(']')
        if (s < 0 || e <= s) return out
        val arr = try { JSONArray(content.substring(s, e + 1)) } catch (ex: Exception) { return out }
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val sl = o.optInt("startLine", -1)
            var el = o.optInt("endLine", -1)
            if (sl < 0 || sl >= lines.size) continue
            if (el < sl) el = sl
            if (el >= lines.size) el = lines.size - 1
            val h = o.optInt("hookScore", 0).coerceIn(0, 10)
            val f = o.optInt("flowScore", 0).coerceIn(0, 10)
            val v = o.optInt("valueScore", 0).coerceIn(0, 10)
            val t = o.optInt("trendScore", 0).coerceIn(0, 10)
            val score = if (h > 0 && f > 0 && v > 0 && t > 0) overall(h, f, v, t) else o.optInt("score", 60).coerceIn(0, 100)
            out.add(
                Moment(
                    lines[sl].startMs, lines[el].endMs,
                    o.optString("title", "").trim(), score,
                    o.optString("reason", "").trim(), true,
                    o.optString("hook", "").trim(), "", "", h, f, v, t
                )
            )
        }
        return out
    }

    // ---------------------------------------------------------------- AI: ranking + editor pass

    private fun aiRank(
        key: String, pool: List<Moment>, lines: List<Line>, limit: Int, total: Long, status: (String) -> Unit
    ): List<Moment>? {
        val arr = JSONArray()
        pool.forEachIndexed { i, m ->
            val snippet = lines.filter { it.startMs >= m.startMs && it.startMs < m.endMs }
                .joinToString(" ") { it.text }.take(200)
            arr.put(
                JSONObject().put("id", i).put("minute", (m.startMs / 60000).toInt()).put("score", m.score)
                    .put("title", m.title).put("hook", m.hook).put("text", snippet)
            )
        }
        val system = "You are an expert viral short-form video editor. The source video is " + (total / 60000 + 1) + " minutes long. " +
                "You get candidate clips as a JSON array; 'minute' is where the clip starts in the video. " +
                "Choose the best " + limit + " clips most likely to go viral: strong hook, emotion, surprise, value, shareability. " +
                "Spread your choice across the whole video (beginning, middle and end): never choose more than 2 clips from the same 5-minute stretch unless the others are clearly weak. " +
                "Prefer a variety of topics and avoid near-duplicate ideas. " +
                "Reply with ONLY a JSON array of the chosen ids, best first, e.g. [3,0,5]."
        val content = GroqClient.chatSmart(key, system, arr.toString(), status)
        val s = content.indexOf('[')
        val e = content.lastIndexOf(']')
        if (s < 0 || e <= s) return null
        val ids = JSONArray(content.substring(s, e + 1))
        val out = ArrayList<Moment>()
        for (i in 0 until ids.length()) {
            val id = ids.optInt(i, -1)
            if (id in pool.indices && !out.contains(pool[id])) out.add(pool[id])
        }
        for (m in pool.sortedByDescending { it.score }) if (!out.contains(m)) out.add(m)
        return out
    }

    /** Re-reads the clip with its surroundings. Returns null when the clip is rejected (weak or incomplete). */
    private fun aiEdit(
        key: String, m: Moment, lines: List<Line>, total: Long,
        minSec: Int, maxSec: Int, langName: String, status: (String) -> Unit
    ): Moment? {
        val si = lines.indexOfLast { it.startMs <= m.startMs + 700 }.coerceAtLeast(0)
        var ei = lines.indexOfFirst { it.endMs >= m.endMs - 700 }
        if (ei < 0) ei = lines.size - 1
        if (ei < si) ei = si
        val from = max(0, si - 8)
        val to = min(lines.size - 1, ei + 8)
        val rows = (from..to).joinToString("\n") { row(it, lines[it]) }

        val system = "You are the final editor of a viral short-form video channel. Each row is: line_id|seconds|text (* = high vocal energy). Language: " + langName + ". " +
                "A candidate clip currently runs from line " + si + " to line " + ei + ". " +
                "Decide the FINAL clip as consecutive lines from startLine to endLine (both between " + from + " and " + to + "), total " + minSec + " to " + maxSec + " seconds (add up the seconds column). " +
                "The startLine must open a thought with the strongest hook and must NOT need earlier context; the endLine must finish the thought right after the payoff, never mid-sentence. " +
                "Set keep=false if the clip is weak, boring, incomplete, mostly filler, or cannot be understood on its own. " +
                "Score the final clip from 0 to 10 for hook, flow, value and trend (be strict). Then write the post: " +
                "title (max 8 words, catchy), hook (the opening idea, max 12 words), description (1-2 sentences with 2-3 emojis), hashtags (3-5), reason (why it can go viral, short), all in " + langName + ". " +
                "Reply with ONLY JSON, no markdown: " +
                "{\"keep\":true,\"startLine\":12,\"endLine\":19,\"title\":\"...\",\"hook\":\"...\",\"description\":\"...\",\"hashtags\":[\"#a\",\"#b\"],\"hookScore\":8,\"flowScore\":7,\"valueScore\":9,\"trendScore\":6,\"reason\":\"...\"}"

        val content = GroqClient.chatSmart(key, system, rows, status)
        val s = content.indexOf('{')
        val e = content.lastIndexOf('}')
        if (s < 0 || e <= s) return m
        val o = JSONObject(content.substring(s, e + 1))
        if (!o.optBoolean("keep", true)) return null

        val s2 = o.optInt("startLine", si).coerceIn(from, to)
        val e2 = o.optInt("endLine", ei).coerceIn(s2, to)
        val h = o.optInt("hookScore", 0).coerceIn(0, 10)
        val f = o.optInt("flowScore", 0).coerceIn(0, 10)
        val v = o.optInt("valueScore", 0).coerceIn(0, 10)
        val t = o.optInt("trendScore", 0).coerceIn(0, 10)
        if (h > 0 && f > 0 && (f <= 3 || h <= 2)) return null

        val cand = Moment(
            lines[s2].startMs, lines[e2].endMs,
            o.optString("title", m.title).trim().ifEmpty { m.title },
            if (h > 0 && f > 0 && v > 0 && t > 0) overall(h, f, v, t) else m.score,
            o.optString("reason", m.reason).trim(),
            true,
            o.optString("hook", m.hook).trim(),
            o.optString("description", "").trim(),
            parseTags(o), h, f, v, t
        )
        return snap(cand, lines, total, minSec, maxSec) ?: m
    }

    // ---------------------------------------------------------------- local helpers

    private fun snap(m: Moment, lines: List<Line>, durationMs: Long, minSec: Int, maxSec: Int): Moment? {
        var si = lines.indexOfLast { it.startMs <= m.startMs + 700 }
        if (si < 0) si = 0
        var ei = lines.indexOfFirst { it.endMs >= m.endMs - 700 }
        if (ei < 0) ei = lines.size - 1
        if (ei < si) ei = si
        val maxMs = maxSec * 1000L
        val minMs = minSec * 1000L
        while (ei > si && lines[ei].endMs - lines[si].startMs > maxMs) ei--
        while (ei < lines.size - 1 && lines[ei].endMs - lines[si].startMs < minMs) ei++
        while (ei > si && lines[ei].endMs - lines[si].startMs > maxMs + 5000) ei--
        val start = max(0L, lines[si].startMs - 250)
        val end = min(durationMs, lines[ei].endMs + 500)
        if (end - start < 8000) return null
        return m.copyWith(start, end)
    }

    private fun overlaps(a: Moment, b: Moment): Boolean {
        val ov = min(a.endMs, b.endMs) - max(a.startMs, b.startMs)
        val shorter = min(a.endMs - a.startMs, b.endMs - b.startMs)
        return ov > shorter * 0.2
    }

    /** Local fallback: scores speech energy, hook words, questions/exclamations and loud lines. */
    private fun heuristic(
        lines: List<Line>, durationMs: Long, minSec: Int, maxSec: Int, take: Int,
        from: Long, to: Long, relaxed: Boolean
    ): List<Moment> {
        val targetMs = ((minSec + maxSec) / 2) * 1000L
        val minDensity = if (relaxed) 0.6 else 1.3
        val minDur = if (relaxed) minSec * 0.4 else minSec * 0.6
        val scored = ArrayList<Pair<Moment, Double>>()
        for (i in lines.indices) {
            if (lines[i].startMs < from || lines[i].startMs >= to) continue
            var j = i
            while (j < lines.size - 1 && lines[j].endMs - lines[i].startMs < targetMs) j++
            val dur = (lines[j].endMs - lines[i].startMs) / 1000.0
            if (dur < minDur) continue
            var words = 0
            var q = 0
            var kw = 0
            var loud = 0
            for (k in i..j) {
                val t = lines[k].text
                words += wordCount(t)
                if (t.contains('?') || t.contains('!')) q++
                val low = t.lowercase()
                for (h in HOOKS) if (low.contains(h)) kw++
                if (lines[k].loud) loud++
            }
            val density = words / dur
            if (density < minDensity) continue
            val score = density * 10 + q * 2.0 + kw * 4.0 + loud * 3.0
            val start = max(0L, lines[i].startMs - 250)
            val end = min(durationMs, lines[j].endMs + 500)
            val m = Moment(start, end, "", 0, "Energetic speech with strong keywords")
            m.hook = lines[i].text.take(80)
            scored.add(m to score)
        }
        if (scored.isEmpty()) return emptyList()
        scored.sortByDescending { it.second }
        val maxS = scored.first().second
        return scored.take(take).mapIndexed { idx, (m, s) ->
            m.score = (45 + 29 * (s / maxS)).toInt()
            m.title = "Short moment " + (idx + 1)
            m
        }
    }
}
