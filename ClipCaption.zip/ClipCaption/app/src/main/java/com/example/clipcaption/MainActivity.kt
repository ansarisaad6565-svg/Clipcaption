package com.example.clipcaption

import android.content.ContentValues
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Shader
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.view.View
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.Spinner
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private val stateFile = "project_main.json"

    private var videoUri: Uri? = null
    private var videoW = 1080
    private var videoH = 1920
    private var durationMs = 0L
    private val captions = mutableListOf<Caption>()
    private var busy = false
    private var lastSaved: Uri? = null

    private lateinit var videoView: VideoView
    private lateinit var tvInfo: TextView
    private lateinit var tvStatus: TextView
    private lateinit var progress: ProgressBar
    private lateinit var ivPreview: ImageView
    private lateinit var llCaptions: LinearLayout
    private lateinit var spLang: Spinner
    private lateinit var spWords: Spinner
    private lateinit var spEngine: Spinner
    private lateinit var spDensity: Spinner
    private lateinit var llKey: LinearLayout
    private lateinit var etKey: EditText
    private lateinit var cbSmart: CheckBox
    private lateinit var spEdit: Spinner
    private lateinit var spSync: Spinner
    private lateinit var spMusic: Spinner
    private lateinit var etHint: EditText
    private lateinit var spStyle: Spinner
    private lateinit var spFont: Spinner
    private lateinit var spSize: Spinner
    private lateinit var spPos: Spinner
    private lateinit var cbEmoji: CheckBox
    private lateinit var btnPick: Button
    private lateinit var btnCaption: Button
    private lateinit var btnExport: Button
    private lateinit var btnShare: Button

    private val handler = Handler(Looper.getMainLooper())
    private var transformer: Transformer? = null

    private val picker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (e: Exception) {
            }
            loadVideo(uri)
        }
    }

    private fun spinners(): Map<String, Spinner> = mapOf(
        "lang" to spLang, "engine" to spEngine, "words" to spWords, "density" to spDensity,
        "style" to spStyle, "font" to spFont, "size" to spSize, "pos" to spPos,
        "edit" to spEdit, "sync" to spSync, "music" to spMusic
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        videoView = findViewById(R.id.videoView)
        tvInfo = findViewById(R.id.tvInfo)
        tvStatus = findViewById(R.id.tvStatus)
        progress = findViewById(R.id.progress)
        ivPreview = findViewById(R.id.ivPreview)
        llCaptions = findViewById(R.id.llCaptions)
        spLang = findViewById(R.id.spLang)
        spWords = findViewById(R.id.spWords)
        spEngine = findViewById(R.id.spEngine)
        spDensity = findViewById(R.id.spDensity)
        llKey = findViewById(R.id.llKey)
        etKey = findViewById(R.id.etKey)
        cbSmart = findViewById(R.id.cbSmart)
        spEdit = findViewById(R.id.spEdit)
        spSync = findViewById(R.id.spSync)
        spMusic = findViewById(R.id.spMusic)
        etHint = findViewById(R.id.etHint)
        spStyle = findViewById(R.id.spStyle)
        spFont = findViewById(R.id.spFont)
        spSize = findViewById(R.id.spSize)
        spPos = findViewById(R.id.spPos)
        cbEmoji = findViewById(R.id.cbEmoji)
        btnPick = findViewById(R.id.btnPick)
        btnCaption = findViewById(R.id.btnCaption)
        btnExport = findViewById(R.id.btnExport)
        btnShare = findViewById(R.id.btnShare)

        setup(spLang, Presets.langNames, 0)
        setup(spEdit, EditFx.levelNames, 0)
        setup(spSync, Presets.syncNames, 0)
        setup(spMusic, MusicFx.names, 0)
        setup(spEngine, listOf("Online AI (Whisper) - bahut accurate", "Offline - free, kam accurate"), 0)
        setup(spWords, listOf("1 word", "2 words", "3 words", "4 words", "5 words"), 1)
        setup(spDensity, listOf("Kam (sirf pakke match)", "Medium", "Zyada (har caption par)"), 1)
        setup(spStyle, Presets.styles.map { it.name }, 2)
        setup(spFont, Presets.fonts.map { it.name }, 1)
        setup(spSize, Presets.sizeNames, 1)
        setup(spPos, Presets.positionNames, 0)

        val previewListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) = updatePreview()
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        spStyle.onItemSelectedListener = previewListener
        spFont.onItemSelectedListener = previewListener
        spSize.onItemSelectedListener = previewListener

        etKey.setText(getSharedPreferences("cc", MODE_PRIVATE).getString("groq", "") ?: "")
        spEngine.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                llKey.visibility = if (pos == 0) View.VISIBLE else View.GONE
            }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        findViewById<Button>(R.id.btnKeyHelp).setOnClickListener {
            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://console.groq.com/keys")))
        }
        findViewById<Button>(R.id.btnShorts).setOnClickListener {
            startActivity(Intent(this, ShortsActivity::class.java))
        }
        btnPick.setOnClickListener { askNewVideo() }
        btnCaption.setOnClickListener { addCaptions() }
        btnExport.setOnClickListener { export() }
        btnShare.setOnClickListener { share() }

        restoreState()
        updatePickLabel()
        updatePreview()

        // if the user was inside the Viral Shorts screen last time, take them back there
        val prefs = getSharedPreferences("cc", MODE_PRIVATE)
        if (savedInstanceState == null && prefs.getString("screen", "") == "shorts" &&
            File(filesDir, "project_shorts.json").exists()
        ) {
            startActivity(Intent(this, ShortsActivity::class.java))
        }
    }

    override fun onResume() {
        super.onResume()
        getSharedPreferences("cc", MODE_PRIVATE).edit().putString("screen", "main").apply()
    }

    override fun onPause() {
        super.onPause()
        saveState()
    }

    private fun setup(sp: Spinner, items: List<String>, sel: Int) {
        sp.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, items)
        sp.setSelection(sel)
    }

    private fun ui(block: () -> Unit) = runOnUiThread(block)

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    private fun setBusy(b: Boolean) {
        busy = b
        btnPick.isEnabled = !b
        btnCaption.isEnabled = !b
        btnExport.isEnabled = !b
    }

    // ---------- keep the project when the app is closed ----------

    private fun saveState() {
        try {
            val o = JSONObject()
            o.put("uri", videoUri?.toString() ?: "")
            o.put("duration", durationMs)
            o.put("w", videoW)
            o.put("h", videoH)
            o.put("saved", lastSaved?.toString() ?: "")
            o.put("hint", etHint.text.toString())
            val caps = JSONArray()
            for (c in captions) caps.put(ProjectIo.captionToJson(c))
            o.put("captions", caps)
            val sp = JSONObject()
            for ((k, v) in spinners()) sp.put(k, v.selectedItemPosition)
            o.put("sp", sp)
            o.put("smart", cbSmart.isChecked)
            o.put("emoji", cbEmoji.isChecked)
            ProjectIo.write(this, stateFile, o)
        } catch (e: Exception) {
        }
    }

    private fun restoreState() {
        val o = ProjectIo.read(this, stateFile) ?: return
        try {
            val sp = o.optJSONObject("sp")
            if (sp != null) for ((k, v) in spinners()) if (sp.has(k)) v.setSelection(sp.getInt(k))
            cbSmart.isChecked = o.optBoolean("smart", true)
            cbEmoji.isChecked = o.optBoolean("emoji", true)
            etHint.setText(o.optString("hint", ""))

            val u = o.optString("uri", "")
            if (u.isNotEmpty()) {
                val uri = Uri.parse(u)
                if (ProjectIo.canRead(this, uri)) {
                    videoUri = uri
                    durationMs = o.optLong("duration", 0)
                    videoW = o.optInt("w", 1080)
                    videoH = o.optInt("h", 1920)
                    videoView.setVideoURI(uri)
                    videoView.setOnPreparedListener { it.isLooping = true; videoView.seekTo(1) }
                    tvInfo.text = "Video: ${durationMs / 1000} sec  (${videoW}x${videoH})"
                } else {
                    tvStatus.text = "Pichla video ab nahi mil raha. Naya video chuno."
                }
            }
            captions.clear()
            val ca = o.optJSONArray("captions")
            if (ca != null) for (i in 0 until ca.length()) captions.add(ProjectIo.captionFromJson(ca.getJSONObject(i)))
            refreshList()

            val saved = o.optString("saved", "")
            if (saved.isNotEmpty()) {
                lastSaved = Uri.parse(saved)
                btnShare.isEnabled = true
            }
            if (videoUri != null && captions.isNotEmpty()) {
                tvStatus.text = "Pichla project wapas aa gaya (${captions.size} captions). Seedha export kar sakte ho."
            }
        } catch (e: Exception) {
        }
    }

    private fun updatePickLabel() {
        btnPick.text = if (videoUri != null) "<- Naya video chuno (back)" else "1. Video upload karo"
    }

    private fun askNewVideo() {
        if (busy) return
        if (videoUri == null && captions.isEmpty()) {
            picker.launch(arrayOf("video/*"))
            return
        }
        AlertDialog.Builder(this)
            .setTitle("Naya video?")
            .setMessage("Naya video chunne par abhi ke captions hat jayenge. Gallery me save ho chuke videos safe rahenge.")
            .setPositiveButton("Haan, naya video") { _, _ ->
                clearProject()
                picker.launch(arrayOf("video/*"))
            }
            .setNegativeButton("Nahi, yahin rehne do", null)
            .show()
    }

    private fun clearProject() {
        videoUri = null
        durationMs = 0
        captions.clear()
        lastSaved = null
        try { videoView.stopPlayback() } catch (e: Exception) { }
        tvInfo.text = "Koi video select nahi hua"
        tvStatus.text = ""
        btnShare.isEnabled = false
        refreshList()
        ProjectIo.delete(this, stateFile)
        updatePickLabel()
    }

    // ---------- video ----------

    private fun loadVideo(uri: Uri) {
        try {
            val r = MediaMetadataRetriever()
            r.setDataSource(this, uri)
            durationMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1080
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1920
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            r.release()
            if (rot == 90 || rot == 270) { videoW = h; videoH = w } else { videoW = w; videoH = h }
        } catch (e: Exception) {
            toast("Video read nahi ho paya: ${e.message}")
            return
        }
        videoUri = uri
        captions.clear()
        lastSaved = null
        refreshList()
        videoView.setVideoURI(uri)
        videoView.setOnPreparedListener { it.isLooping = true; videoView.start() }
        tvInfo.text = "Video: ${durationMs / 1000} sec  (${videoW}x${videoH})"
        tvStatus.text = "Ab 'Add Captions' dabao."
        btnShare.isEnabled = false
        updatePickLabel()
        updatePreview()
        saveState()
    }

    // ---------- auto captions ----------

    private fun addCaptions() {
        val uri = videoUri
        if (uri == null) { toast("Pehle video upload karo"); return }
        if (busy) return

        val online = spEngine.selectedItemPosition == 0
        val key = etKey.text.toString().trim()
        if (online && key.isEmpty()) {
            toast("Groq API key daalo (free) ya Offline engine chuno")
            etKey.requestFocus()
            return
        }
        if (online) getSharedPreferences("cc", MODE_PRIVATE).edit().putString("groq", key).apply()

        setBusy(true)
        progress.isIndeterminate = true

        val langPos = spLang.selectedItemPosition
        val langKey = when (langPos) { 0 -> "hinglish"; 1 -> "hi"; else -> "en" }
        val perCap = spWords.selectedItemPosition + 1
        val density = spDensity.selectedItemPosition
        val smart = cbSmart.isChecked
        val hint = etHint.text.toString().trim()
        val hintPrefix = if (hint.isEmpty()) "" else "Names and keywords: $hint. "

        thread {
            try {
                val raw: List<RawWord>
                if (online) {
                    ui { tvStatus.text = "Audio nikal raha hoon..." }
                    val pcm = File(cacheDir, "audio.pcm")
                    FileOutputStream(pcm).use { fo ->
                        AudioDecoder.decode(
                            this, uri,
                            { b, n -> fo.write(b, 0, n) },
                            { p -> ui { tvStatus.text = "Audio nikal raha hoon... $p%" } }
                        )
                    }
                    // Auto (0): Whisper detects the language itself. English stays English,
                    // Hindi comes back in Devanagari and is converted to Hinglish (Roman) below.
                    val apiLang = when (langPos) { 0 -> ""; 1 -> "hi"; else -> "en" }
                    val prompt = hintPrefix + (if (langPos == 1) GroqClient.HINDI_PROMPT else "")
                    raw = GroqClient.transcribe(pcm, key, apiLang, prompt) { m -> ui { tvStatus.text = m } }
                    pcm.delete()
                } else {
                    val modelCode = if (langPos == 2) "en" else "hi"
                    val path = ModelManager.ensure(this, modelCode) { m -> ui { tvStatus.text = m } }
                    ui { tvStatus.text = "Speech model load ho raha hai..." }
                    raw = Transcriber.run(this, uri, path) { m -> ui { tvStatus.text = m } }
                }

                if (raw.isEmpty()) {
                    ui { tvStatus.text = "Koi speech nahi mili. Dusri language ya engine try karo." }
                } else {
                    var useRaw: List<RawWord> = raw
                    if (online && smart) {
                        try {
                            useRaw = GroqClient.fixWords(key, raw, langKey) { m -> ui { tvStatus.text = m } }
                        } catch (e: GroqClient.ApiException) {
                            if (e.code == 401) throw e
                        } catch (e: Exception) {
                            // keep original words
                        }
                    }
                    val caps = CaptionBuilder.build(useRaw, langKey, perCap, density)
                    var note = ""
                    if (online && smart) {
                        try {
                            GroqClient.smartFix(key, caps, langKey, density) { m -> ui { tvStatus.text = m } }
                            CaptionBuilder.dedupeEmoji(caps)
                        } catch (e: Exception) {
                            note = " (AI emoji nahi lag paye: ${e.message})"
                        }
                    }
                    val withEmoji = caps.count { it.emoji.isNotEmpty() }
                    ui {
                        captions.clear()
                        captions.addAll(caps)
                        refreshList()
                        tvStatus.text = "${caps.size} captions, ${withEmoji} emoji ke saath. Galat word ho to caption par tap karke theek karo, fir Export dabao.$note"
                        saveState()
                    }
                }
            } catch (t: Throwable) {
                ui { tvStatus.text = "Error: ${t.message ?: t.javaClass.simpleName}" }
            } finally {
                ui { progress.isIndeterminate = false; setBusy(false) }
            }
        }
    }

    private fun refreshList() {
        llCaptions.removeAllViews()
        if (captions.isEmpty()) {
            llCaptions.addView(TextView(this).apply { text = "Abhi koi caption nahi" })
            return
        }
        for (cap in captions) {
            val tv = TextView(this)
            tv.text = "${fmt(cap.startMs)}   ${cap.text} ${cap.emoji}"
            tv.textSize = 16f
            tv.setPadding(0, 14, 0, 14)
            tv.setOnClickListener { editDialog(cap) }
            llCaptions.addView(tv)
        }
    }

    private fun editDialog(cap: Caption) {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(48, 16, 48, 0)
        val etText = EditText(this)
        etText.setText(cap.text)
        etText.hint = "Caption text"
        val etEmoji = EditText(this)
        etEmoji.setText(cap.emoji)
        etEmoji.hint = "Emoji (khali = nahi)"
        box.addView(etText)
        box.addView(etEmoji)
        AlertDialog.Builder(this)
            .setTitle("Caption edit")
            .setView(box)
            .setPositiveButton("Save") { _, _ ->
                cap.setText(etText.text.toString())
                cap.emoji = etEmoji.text.toString().trim()
                refreshList()
                saveState()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------- style preview ----------

    private fun makeRenderer(): CaptionRenderer = CaptionRenderer(
        videoW, videoH,
        Presets.styles[spStyle.selectedItemPosition],
        Presets.fonts[spFont.selectedItemPosition].typeface(),
        Presets.sizeScales[spSize.selectedItemPosition]
    )

    private fun updatePreview() {
        if (!::spStyle.isInitialized || !::ivPreview.isInitialized) return
        try {
            val cap = makeRenderer().render(listOf("Ye", "caption", "aise", "dikhega"), 1, "🔥")
            val w = videoW
            val h = (cap.height * 2.2f).toInt().coerceAtLeast(160)
            val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(out)
            val p = Paint()
            p.shader = LinearGradient(0f, 0f, w.toFloat(), h.toFloat(), 0xFF455A64.toInt(), 0xFF1B1B1B.toInt(), Shader.TileMode.CLAMP)
            c.drawRect(0f, 0f, w.toFloat(), h.toFloat(), p)
            c.drawBitmap(cap, (w - cap.width) / 2f, (h - cap.height) / 2f, null)
            ivPreview.setImageBitmap(out)
        } catch (e: Exception) {
            // preview is optional
        }
    }

    // ---------- export ----------

    private fun export() {
        val uri = videoUri
        if (uri == null) { toast("Pehle video upload karo"); return }
        if (captions.isEmpty()) { toast("Pehle 'Add Captions' dabao"); return }
        if (busy) return

        val style = Presets.styles[spStyle.selectedItemPosition]
        val level = spEdit.selectedItemPosition
        val capsCopy = captions.toList()
        val overlays = ArrayList<TextureOverlay>()
        EditFx.progressOverlay(level, durationMs, videoW, videoH)?.let { overlays.add(it) }
        overlays.add(
            CaptionBitmapOverlay(
                capsCopy, makeRenderer(), cbEmoji.isChecked, spPos.selectedItemPosition,
                style.useHighlight, level < 2, Presets.syncMs[spSync.selectedItemPosition]
            )
        )
        EditFx.fadeOverlay(level, durationMs, videoW, videoH)?.let { overlays.add(it) }
        val effects = ArrayList<Effect>()
        effects.addAll(EditFx.videoEffects(level, EditFx.cutsFrom(capsCopy)))
        effects.add(OverlayEffect(ImmutableList.copyOf(overlays)))
        val edited = EditedMediaItem.Builder(MediaItem.fromUri(uri))
            .setEffects(Effects(MusicFx.processors(spMusic.selectedItemPosition, durationMs), effects))
            .build()

        val outFile = File(cacheDir, "cc_${System.currentTimeMillis()}.mp4")
        setBusy(true)
        progress.progress = 0
        tvStatus.text = "Export ho raha hai... (screen on rakho)"

        val t = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    handler.removeCallbacks(poller)
                    progress.progress = 100
                    tvStatus.text = "Gallery me save ho raha hai..."
                    saveToGallery(outFile)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    handler.removeCallbacks(poller)
                    setBusy(false)
                    tvStatus.text = "Export error: ${exportException.message}"
                }
            })
            .build()
        transformer = t
        t.start(edited, outFile.absolutePath)
        handler.post(poller)
    }

    private val poller = object : Runnable {
        override fun run() {
            val t = transformer ?: return
            val holder = ProgressHolder()
            if (t.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) {
                progress.progress = holder.progress
            }
            handler.postDelayed(this, 300)
        }
    }

    private fun saveToGallery(file: File) {
        thread {
            var saved: Uri? = null
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "ClipCaption_${System.currentTimeMillis()}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ClipCaption")
                }
                saved = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (saved != null) {
                    contentResolver.openOutputStream(saved)?.use { out ->
                        file.inputStream().use { it.copyTo(out) }
                    }
                }
                file.delete()
            } catch (e: Exception) {
                ui { tvStatus.text = "Save error: ${e.message}"; setBusy(false) }
                return@thread
            }
            val result: Uri? = saved
            ui {
                setBusy(false)
                lastSaved = result
                btnShare.isEnabled = result != null
                tvStatus.text = "Ho gaya! Movies/ClipCaption folder me save hua. Captions abhi bhi yahin hain, dusra export kar sakte ho."
                saveState()
            }
        }
    }

    private fun share() {
        val u = lastSaved ?: return
        val i = Intent(Intent.ACTION_SEND)
        i.type = "video/mp4"
        i.putExtra(Intent.EXTRA_STREAM, u)
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        startActivity(Intent.createChooser(i, "Share video"))
    }

    private fun fmt(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }

    override fun onDestroy() {
        handler.removeCallbacks(poller)
        transformer?.cancel()
        super.onDestroy()
    }
}
