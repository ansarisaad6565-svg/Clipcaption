package com.example.clipcaption

import android.content.ContentValues
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.widget.Button
import android.widget.EditText
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Effects
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.ProgressHolder
import androidx.media3.transformer.Composition
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import java.io.File
import kotlin.concurrent.thread
import kotlin.math.max
import kotlin.math.min

class MainActivity : AppCompatActivity() {

    private data class Cap(val text: String, val startMs: Long, val endMs: Long)

    private var videoUri: Uri? = null
    private var durationMs = 0L
    private var videoWidth = 1080
    private val captions = mutableListOf<Cap>()

    private lateinit var videoView: VideoView
    private lateinit var tvInfo: TextView
    private lateinit var tvCaptions: TextView
    private lateinit var tvStatus: TextView
    private lateinit var progress: ProgressBar
    private lateinit var etStart: EditText
    private lateinit var etEnd: EditText
    private lateinit var etCaption: EditText
    private lateinit var etCapStart: EditText
    private lateinit var etCapEnd: EditText
    private lateinit var btnExport: Button

    private val handler = Handler(Looper.getMainLooper())
    private var transformer: Transformer? = null

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) loadVideo(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        videoView = findViewById(R.id.videoView)
        tvInfo = findViewById(R.id.tvInfo)
        tvCaptions = findViewById(R.id.tvCaptions)
        tvStatus = findViewById(R.id.tvStatus)
        progress = findViewById(R.id.progress)
        etStart = findViewById(R.id.etStart)
        etEnd = findViewById(R.id.etEnd)
        etCaption = findViewById(R.id.etCaption)
        etCapStart = findViewById(R.id.etCapStart)
        etCapEnd = findViewById(R.id.etCapEnd)
        btnExport = findViewById(R.id.btnExport)

        findViewById<Button>(R.id.btnPick).setOnClickListener { picker.launch("video/*") }
        findViewById<Button>(R.id.btnAddCaption).setOnClickListener { addCaption() }
        findViewById<Button>(R.id.btnClear).setOnClickListener { captions.clear(); refreshCaptions() }
        btnExport.setOnClickListener { export() }
    }

    private fun loadVideo(uri: Uri) {
        try {
            val r = MediaMetadataRetriever()
            r.setDataSource(this, uri)
            durationMs = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
            val w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 1080
            val h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 1920
            val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            r.release()
            videoWidth = if (rot == 90 || rot == 270) h else w
        } catch (e: Exception) {
            Toast.makeText(this, "Video read nahi ho paya: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }
        videoUri = uri
        videoView.setVideoURI(uri)
        videoView.setOnPreparedListener { it.isLooping = true; videoView.start() }
        tvInfo.text = "Video length: ${fmt(durationMs)}"
        etStart.setText("0")
        etEnd.setText(fmt(durationMs))
    }

    private fun addCaption() {
        val text = etCaption.text.toString().trim()
        val s = parseTime(etCapStart.text.toString())
        val e = parseTime(etCapEnd.text.toString())
        if (text.isEmpty() || s == null || e == null || e <= s) {
            Toast.makeText(this, "Caption text aur sahi start/end time daalo", Toast.LENGTH_SHORT).show()
            return
        }
        captions.add(Cap(text, s, e))
        etCaption.setText("")
        refreshCaptions()
    }

    private fun refreshCaptions() {
        tvCaptions.text = if (captions.isEmpty()) "Abhi koi caption nahi"
        else captions.sortedBy { it.startMs }.joinToString("\n") { "${fmt(it.startMs)} - ${fmt(it.endMs)}  ${it.text}" }
    }

    private fun export() {
        val uri = videoUri
        if (uri == null) { toast("Pehle video chuno"); return }
        val start = parseTime(etStart.text.toString())
        val end = parseTime(etEnd.text.toString())
        if (start == null || end == null || end <= start || (durationMs > 0 && end > durationMs + 500)) {
            toast("Start/End time sahi daalo (video ${fmt(durationMs)} ka hai)")
            return
        }

        val relCaps = captions.mapNotNull { c ->
            val s = max(c.startMs, start) - start
            val e = min(c.endMs, end) - start
            if (e > s) TimedCaption(c.text, s * 1000, e * 1000) else null
        }

        val clip = MediaItem.ClippingConfiguration.Builder()
            .setStartPositionMs(start)
            .setEndPositionMs(end)
            .build()
        val item = MediaItem.Builder().setUri(uri).setClippingConfiguration(clip).build()

        val videoEffects: List<Effect> =
            if (relCaps.isEmpty()) emptyList()
            else listOf(
                OverlayEffect(
                    ImmutableList.of<TextureOverlay>(CaptionOverlay(relCaps, max(24, videoWidth / 18)))
                )
            )
        val edited = EditedMediaItem.Builder(item)
            .setEffects(Effects(emptyList(), videoEffects))
            .build()

        val outFile = File(cacheDir, "clip_${System.currentTimeMillis()}.mp4")
        btnExport.isEnabled = false
        progress.progress = 0
        tvStatus.text = "Export ho raha hai..."

        val t = Transformer.Builder(this)
            .addListener(object : Transformer.Listener {
                override fun onCompleted(composition: Composition, exportResult: ExportResult) {
                    stopPolling()
                    progress.progress = 100
                    tvStatus.text = "Gallery me save ho raha hai..."
                    saveToGallery(outFile)
                }

                override fun onError(
                    composition: Composition,
                    exportResult: ExportResult,
                    exportException: ExportException
                ) {
                    stopPolling()
                    btnExport.isEnabled = true
                    tvStatus.text = "Error: ${exportException.message}"
                }
            })
            .build()
        transformer = t
        t.start(edited, outFile.absolutePath)
        startPolling()
    }

    private val poller = object : Runnable {
        override fun run() {
            val t = transformer ?: return
            val holder = ProgressHolder()
            if (t.getProgress(holder) != Transformer.PROGRESS_STATE_NOT_STARTED) {
                progress.progress = holder.progress
            }
            handler.postDelayed(this, 300)
        }
    }

    private fun startPolling() = handler.post(poller)
    private fun stopPolling() = handler.removeCallbacks(poller)

    private fun saveToGallery(file: File) {
        thread {
            var saved: Uri? = null
            try {
                val values = ContentValues().apply {
                    put(MediaStore.Video.Media.DISPLAY_NAME, "ClipCaption_${System.currentTimeMillis()}.mp4")
                    put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
                    put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/ClipCaption")
                }
                saved = contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values)
                if (saved != null) {
                    contentResolver.openOutputStream(saved)?.use { out ->
                        file.inputStream().use { it.copyTo(out) }
                    }
                }
                file.delete()
            } catch (e: Exception) {
                runOnUiThread { tvStatus.text = "Save error: ${e.message}"; btnExport.isEnabled = true }
                return@thread
            }
            runOnUiThread {
                btnExport.isEnabled = true
                tvStatus.text = "Ho gaya! Movies/ClipCaption folder me save hua."
                if (saved != null) {
                    videoView.setVideoURI(saved)
                    videoView.start()
                }
            }
        }
    }

    private fun parseTime(s: String): Long? {
        val t = s.trim().replace(',', '.')
        if (t.isEmpty()) return null
        return try {
            var sec = 0.0
            for (p in t.split(":")) sec = sec * 60 + p.toDouble()
            (sec * 1000).toLong()
        } catch (e: NumberFormatException) {
            null
        }
    }

    private fun fmt(ms: Long): String {
        val total = ms / 1000
        return "%d:%02d".format(total / 60, total % 60)
    }

    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        stopPolling()
        transformer?.cancel()
        super.onDestroy()
    }
}
